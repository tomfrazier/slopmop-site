//#region src/shared/manifest.ts
/**
* The fixed values the extension runs on. The server publishes them as a manifest (see the server's manifest.ts) that the
* extension keeps for a day and refreshes when an answer reports a newer version, so any of them can change without a new
* release. These defaults are what applies before the first manifest arrives, and for any value the manifest leaves out.
*/
var SECOND_MS$1 = 1e3;
var HOUR_MS$1 = 60 * (60 * SECOND_MS$1);
var DAY_MS$1 = 24 * HOUR_MS$1;
var DEFAULT_MANIFEST = {
	requestTimeoutMs: 15 * SECOND_MS$1,
	maxAttempts: 3,
	baseBackoffMs: 500,
	maxRetryPauseMs: 8 * SECOND_MS$1,
	maxRateLimitWaits: 5,
	maxRateLimitPauseS: 60,
	defaultRateLimitPauseS: 5,
	blockedRecheckMs: HOUR_MS$1,
	cacheTtlMs: 7 * DAY_MS$1,
	engagementBandGrowth: 1.25,
	lookaheadPx: 1500,
	dropBeyondPx: 200,
	scrollHintMs: 200,
	rescanDelayMs: 250,
	postRetryDelaysMs: [
		8 * SECOND_MS$1,
		30 * SECOND_MS$1,
		90 * SECOND_MS$1
	],
	minChars: 200,
	minOwnChars: 60,
	yellowFraction: .6,
	minMeanConfidence: .25,
	aiDampen: .35,
	strongSign: .4,
	flaggedSign: .2,
	displayPossibly: 40,
	displayLikely: 70,
	displayFullMultiple: 2,
	defaultDailyLimit: 250
};
var MANIFEST_KEY = "manifest";
/** The values in force in this script. Read `live.values.x` where the value is used, never at import time. */
var live = {
	values: { ...DEFAULT_MANIFEST },
	thresholds: null,
	version: null
};
var okThresholds = (t) => {
	const x = t;
	const ok = (n) => typeof n === "number" && n > 0 && n <= 1;
	return !!x && ok(x.aggressive) && ok(x.moderate) && ok(x.mild) && x.aggressive <= x.moderate && x.moderate <= x.mild;
};
/** Keeps only values of the right kind, so a bad manifest can never break a setting. */
function sane(values) {
	const out = {};
	for (const [key, def] of Object.entries(DEFAULT_MANIFEST)) {
		const v = values?.[key];
		if (Array.isArray(def)) {
			if (Array.isArray(v) && v.length > 0 && v.every((n) => typeof n === "number" && Number.isFinite(n) && n > 0)) out[key] = v;
		} else if (typeof v === "number" && Number.isFinite(v) && v > 0) out[key] = v;
	}
	return out;
}
/** Makes a stored manifest the one in force (or the defaults, when there is none or it is unusable). */
function applyManifest(stored) {
	const s = stored;
	live.values = {
		...DEFAULT_MANIFEST,
		...sane(s?.values)
	};
	live.thresholds = okThresholds(s?.thresholds) ? s.thresholds : null;
	live.version = typeof s?.version === "string" ? s.version : null;
}
/** Loads the saved manifest and follows changes to it. Call once when a script starts. */
async function watchManifest() {
	applyManifest((await chrome.storage.local.get(MANIFEST_KEY))[MANIFEST_KEY]);
	chrome.storage.onChanged.addListener((changes, area) => {
		if (area === "local" && changes["manifest"]) applyManifest(changes[MANIFEST_KEY].newValue);
	});
}
/** The manifest's own validation of a fetched body, for the background worker. */
function toStored(body, now) {
	const b = body;
	if (!b || typeof b.version !== "string" || typeof b.ttlSeconds !== "number" || b.ttlSeconds <= 0 || !okThresholds(b.thresholds)) return null;
	return {
		version: b.version,
		values: sane(b.values),
		thresholds: b.thresholds,
		at: now,
		ttlMs: b.ttlSeconds * SECOND_MS$1
	};
}
//#endregion
//#region src/shared/engagement.ts
/** Each step up in this is about 25% more (the manifest's engagementBandGrowth) reactions, comments and reposts together: a post is worth asking the server about again when its step changes. */
var engagementBand = (e) => Math.round(Math.log1p(e.reactions + e.comments + e.reposts) / Math.log(live.values.engagementBandGrowth));
//#endregion
//#region src/shared/types.ts
var DEFAULT_SETTINGS = {
	enabled: false,
	mode: "hide",
	sensitivity: "moderate",
	acknowledged: false,
	debug: false
};
//#endregion
//#region src/shared/settings.ts
async function getSettings() {
	const { settings } = await chrome.storage.sync.get("settings");
	return {
		...DEFAULT_SETTINGS,
		...settings
	};
}
//#endregion
//#region src/shared/constants.ts
/** Named values used across the extension, so no rule is an unexplained number in the middle of some logic. */
var SECOND_MS = 1e3;
var MINUTE_MS = 60 * SECOND_MS;
24 * (60 * MINUTE_MS);
/** Statuses that are worth retrying: rate limited, upstream overloaded, bad gateway, unavailable. */
var TRANSIENT_STATUSES = [
	429,
	502,
	503,
	529
];
/** A modest start; the server's policy replaces it as soon as any answer arrives. */
var FALLBACK_POLICY = {
	maxConcurrent: 2,
	ratePerMinute: 30
};
var BADGE = {
	hidden: "#D93025",
	off: "#6E757D",
	debug: "#2F6FBF",
	error: "#D93025"
};
//#endregion
//#region src/shared/stats.ts
var emptyStats = () => ({
	hidden: {},
	flagged: {},
	seen: {}
});
var dayKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
/** Returns a new StatsData; unchanged if the urn was already counted for this kind. */
function record(data, kind, urn, now) {
	const seenKey = `${kind}:${urn}`;
	if (data.seen[seenKey]) return data;
	const key = dayKey(now);
	return {
		...data,
		[kind]: {
			...data[kind],
			[key]: (data[kind][key] ?? 0) + 1
		},
		seen: {
			...data.seen,
			[seenKey]: key
		}
	};
}
function summarize(counts, now) {
	const todayKey = dayKey(now);
	const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);
	const monthKey = todayKey.slice(0, 7);
	let today = 0, week = 0, month = 0, total = 0, best = 0, bestBeforeToday = 0;
	for (const [key, n] of Object.entries(counts)) {
		total += n;
		best = Math.max(best, n);
		if (key === todayKey) today += n;
		else bestBeforeToday = Math.max(bestBeforeToday, n);
		if (key.startsWith(monthKey)) month += n;
		const [y, m, d] = key.split("-").map(Number);
		if (new Date(y, m - 1, d) >= weekStart && key <= todayKey) week += n;
	}
	const dial = best === 0 ? 0 : today / best;
	return {
		today,
		week,
		month,
		total,
		record: best,
		dial,
		isNewRecord: today > 0 && today >= best && today > bestBeforeToday
	};
}
//#endregion
//#region src/background/statsStore.ts
async function loadStats() {
	return (await chrome.storage.local.get("stats")).stats ?? emptyStats();
}
function statsReply(d) {
	const now = /* @__PURE__ */ new Date();
	return {
		hidden: summarize(d.hidden, now),
		flagged: summarize(d.flagged, now)
	};
}
//#endregion
//#region src/background/tabStorage.ts
var blank = () => ({
	detected: 0,
	ads: 0,
	own: 0,
	skipped: 0,
	sent: 0,
	cached: 0,
	errors: 0,
	lastError: null
});
var tabKey = (id) => `tab:${id}`;
async function getTab(tabId) {
	return (await chrome.storage.session.get(tabKey(tabId)))[tabKey(tabId)] ?? blank();
}
var putTab = (tabId, state) => chrome.storage.session.set({ [tabKey(tabId)]: state });
/** The ids of every tab with saved counters. */
async function knownTabs() {
	return Object.keys(await chrome.storage.session.get(null)).filter((k) => k.startsWith("tab:")).map((k) => Number(k.slice(4)));
}
/** The counters of every open tab added together (the settings page has no tab of its own to ask about). */
async function allTabs() {
	const sum = blank();
	for (const id of await knownTabs()) {
		const t = await getTab(id);
		for (const k of [
			"detected",
			"ads",
			"own",
			"skipped",
			"sent",
			"cached",
			"errors"
		]) sum[k] += t[k];
		sum.lastError = t.lastError ?? sum.lastError;
	}
	return sum;
}
//#endregion
//#region src/background/badge.ts
/**
* The toolbar badge. Normal: posts hidden today ("off" when disabled). Debug: posts sent to the server on this page load
* (resets on reload), blue normally and red once a request has failed.
*/
async function refreshBadge(tabId, state) {
	const s = await getSettings();
	const hiddenToday = statsReply(await loadStats()).hidden.today;
	const normal = !s.enabled ? "off" : hiddenToday ? String(hiddenToday) : "";
	const normalColor = !s.enabled ? BADGE.off : BADGE.hidden;
	await chrome.action.setBadgeText({ text: normal });
	await chrome.action.setBadgeBackgroundColor({ color: normalColor });
	const debug = s.enabled && s.debug;
	for (const id of tabId !== void 0 ? [tabId] : await knownTabs()) {
		const t = state && id === tabId ? state : await getTab(id);
		try {
			await chrome.action.setBadgeText({
				tabId: id,
				text: debug ? String(t.sent) : normal
			});
			await chrome.action.setBadgeBackgroundColor({
				tabId: id,
				color: debug ? t.errors ? BADGE.error : BADGE.debug : normalColor
			});
		} catch {}
	}
}
//#endregion
//#region src/shared/config.ts
/** Set with SLOPMOP_SERVER_URL at build time; defaults to a local `npm run dev` server in slopmop-server. */
var SERVER_URL = "https://api.slopmop.lol";
/** The server's versioned API. On Vercel, files under api/ are served at /api/..., so this works with no rewrites. */
var API_BASE = `${SERVER_URL}/api/v1`;
var NETWORK = "linkedin";
//#endregion
//#region src/background/installId.ts
/** A random id created at install: anonymous, and only used by the server for its per-install limits. */
async function installId() {
	const { installId } = await chrome.storage.local.get("installId");
	if (typeof installId === "string") return installId;
	const id = crypto.randomUUID();
	await chrome.storage.local.set({ installId: id });
	return id;
}
//#endregion
//#region src/background/policy.ts
var policy = { ...FALLBACK_POLICY };
var onChange = () => {};
var validPolicy = (p) => {
	const x = p;
	return !!x && Number.isInteger(x.maxConcurrent) && x.maxConcurrent >= 1 && x.maxConcurrent <= 32 && Number.isInteger(x.ratePerMinute) && x.ratePerMinute >= 1 && x.ratePerMinute <= 1e4;
};
chrome.storage.local.get("policy").then((r) => {
	if (validPolicy(r.policy)) policy = r.policy;
});
var currentPolicy = () => policy;
/** The queue asks to be told when a policy change might let waiting requests start. */
var onPolicyChange = (fn) => onChange = fn;
function learnPolicy(p) {
	if (!validPolicy(p) || p.maxConcurrent === policy.maxConcurrent && p.ratePerMinute === policy.ratePerMinute) return;
	policy = p;
	chrome.storage.local.set({ policy });
	onChange();
}
var startedAt = [];
var pausedUntil = 0;
var noteRequestStart = () => void startedAt.push(Date.now());
/** No new request may start until `ms` from now (used when the server says "slow down"). */
var pauseFor = (ms) => pausedUntil = Math.max(pausedUntil, Date.now() + ms);
var pausedForMs = () => Math.max(0, pausedUntil - Date.now());
/** Milliseconds until another request may start under the policy (0 = now). */
function startDelay() {
	const now = Date.now();
	while (startedAt.length && startedAt[0] <= now - 6e4) startedAt.shift();
	let wait = pausedForMs();
	if (startedAt.length >= policy.ratePerMinute) wait = Math.max(wait, startedAt[0] + MINUTE_MS - now);
	return wait;
}
//#endregion
//#region src/background/serverState.ts
var timeOf = (iso) => new Date(iso).toLocaleTimeString([], {
	hour: "numeric",
	minute: "2-digit"
});
var limitMessage = (u) => `Daily limit of ${u.limit} checks reached. It resets at ${timeOf(u.resetsAt)}.`;
async function activeHold(key) {
	const hold = (await chrome.storage.local.get(key))[key];
	return hold && Date.now() < hold.until ? hold : null;
}
var dailyLimitHold = () => activeHold("dailyLimit");
var blockedHold = () => activeHold("blocked");
/** The per-install daily cap: retrying can't help until it resets, so remember it and stop asking. */
function rememberDailyLimit(usage, message) {
	return chrome.storage.local.set({
		usage,
		dailyLimit: {
			until: Date.parse(usage.resetsAt),
			message
		}
	});
}
/** The admin turned this install off. Remember it and stop asking for a while. */
function rememberBlocked(message) {
	return chrome.storage.local.set({ blocked: {
		until: Date.now() + live.values.blockedRecheckMs,
		message
	} });
}
//#endregion
//#region src/background/judgeFailure.ts
/** The server's own explanation of an error, when it gave one (it always answers with {error, message}). */
async function serverMessage(res) {
	try {
		return await res.clone().json();
	} catch {
		return {};
	}
}
/** Seconds the server asked us to wait (Retry-After), or 0. */
var retryAfterSeconds = (res) => {
	const asked = Number(res.headers.get("retry-after"));
	return Number.isFinite(asked) && asked > 0 ? asked : 0;
};
var describeNetworkError = (e) => e instanceof DOMException && e.name === "TimeoutError" ? `timed out after ${live.values.requestTimeoutMs / SECOND_MS}s (${SERVER_URL})` : `network: ${e instanceof Error ? e.message : String(e)} (${SERVER_URL})`;
/** Works out what a failed response means: stop, wait for the rate limit, or back off and retry. */
async function interpretFailure(res, backoffMs) {
	const body = await serverMessage(res);
	if (res.status === 429 && body.error === "daily_limit" && body.usage) {
		const error = limitMessage(body.usage);
		await rememberDailyLimit(body.usage, error);
		return {
			kind: "stop",
			error
		};
	}
	if (res.status === 403 && body.error === "client_disabled") {
		const error = body.message ?? "This install has been disabled by the Slop Mop server.";
		await rememberBlocked(error);
		return {
			kind: "stop",
			error
		};
	}
	learnPolicy(body.policy);
	const error = `server ${res.status}${body.message ? `: ${body.message}` : ""}`;
	const asked = retryAfterSeconds(res);
	const pauseMs = asked ? Math.min(Math.max(backoffMs, asked * SECOND_MS), live.values.maxRetryPauseMs) : backoffMs;
	if (res.status === 429 && body.error === "rate_limited") {
		const waitMs = Math.min(Math.max(asked || live.values.defaultRateLimitPauseS, 1), live.values.maxRateLimitPauseS) * SECOND_MS;
		return {
			kind: "rate",
			error: `server ${res.status}: ${body.message ?? "rate limited"}`,
			waitMs,
			pauseMs
		};
	}
	return TRANSIENT_STATUSES.includes(res.status) ? {
		kind: "retry",
		error,
		pauseMs
	} : {
		kind: "stop",
		error
	};
}
//#endregion
//#region src/background/manifest.ts
/**
* Keeps the manifest (the server's fixed values for this extension) fresh: it is fetched when there is none, when the saved
* one is older than the server said to keep it, and whenever an answer reports a version different from the one held.
*/
var fetching = null;
/** Fetches the manifest and saves it. Failures change nothing: the saved one (or the defaults) stays in force. */
function refreshManifest() {
	fetching ??= (async () => {
		try {
			const res = await fetch(`${API_BASE}/manifest`, {
				signal: AbortSignal.timeout(live.values.requestTimeoutMs),
				headers: { "x-install-id": await installId() }
			});
			if (!res.ok) return;
			const stored = toStored(await res.json(), Date.now());
			if (stored) {
				applyManifest(stored);
				await chrome.storage.local.set({ [MANIFEST_KEY]: stored });
			}
		} catch {}
	})().finally(() => fetching = null);
	return fetching;
}
/** Called with every answer's `manifestVersion`: a different one means the server's values have changed. */
function learnManifestVersion(v) {
	if (typeof v === "string" && v !== live.version) refreshManifest();
}
/** Asks for the manifest if there is none or it has expired, but only while the extension is on. */
async function refreshManifestIfStale() {
	const s = await getSettings();
	if (!s.enabled || !s.acknowledged) return;
	const saved = (await chrome.storage.local.get(MANIFEST_KEY))[MANIFEST_KEY];
	if (!saved || Date.now() - saved.at >= saved.ttlMs) await refreshManifest();
}
//#endregion
//#region src/shared/serial.ts
/**
* Runs async jobs one at a time, in the order they were asked for, so two writes to the same storage key can't lose an update.
* A job that fails doesn't stop the ones behind it, and its caller still sees the failure.
*/
function createSerial() {
	let chain = Promise.resolve();
	return (job) => {
		const result = chain.then(job);
		chain = result.catch(() => void 0);
		return result;
	};
}
//#endregion
//#region src/background/tabs.ts
var serial$1 = createSerial();
/** Changes one tab's debug counters. Updates are serialized so two at once can't lose one. */
function updateTab(tabId, fn) {
	if (tabId === void 0) return Promise.resolve();
	return serial$1(async () => {
		const next = fn(await getTab(tabId));
		await putTab(tabId, next);
		await refreshBadge(tabId, next);
	});
}
//#endregion
//#region src/shared/text.ts
/**
* Same normalisation the server uses to identify content: a post is the same post whatever its whitespace, case,
* zero-width characters or Unicode form. Used here as the local cache key, so a post scored in one LinkedIn view
* (feed, profile carousel, "see all") is reused in the others instead of spending another daily check.
*/
function normalizeText(text) {
	return text.normalize("NFKC").replace(/[​-‍⁠﻿]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
}
//#endregion
//#region src/background/verdictCache.ts
async function hash(s) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
	return [...new Uint8Array(buf)].slice(0, 12).map((b) => b.toString(16).padStart(2, "0")).join("");
}
/** Keyed by the post's text, not the view-specific id, so the same post in another LinkedIn view is a cache hit. */
var cacheKey = (text) => hash(`${NETWORK}\n${normalizeText(text)}`);
var weightsVersion = null;
var versionLoaded = chrome.storage.local.get("weightsVersion").then((r) => {
	if (typeof r.weightsVersion === "string") weightsVersion = r.weightsVersion;
});
function learnWeightsVersion(v) {
	if (typeof v !== "string" || v === weightsVersion) return;
	weightsVersion = v;
	chrome.storage.local.set({ weightsVersion: v });
}
/**
* A saved answer we can still use, or null. Refetch entries that predate the content registry (no contentId) or the private
* tell weights (no tellMean), ones scored under weights the server has since changed, ones past their time, and ones whose
* post has since gained enough engagement (`band`, the post's current step) that the server's shield would now differ.
*/
async function readCached(key, band) {
	const got = (await chrome.storage.local.get(`v:${key}`))[`v:${key}`];
	await versionLoaded;
	if (!got) return null;
	const sameWeights = weightsVersion === null || got.response.weightsVersion === weightsVersion;
	const complete = !!got.response.contentId && got.response.tellMean !== void 0;
	const age = Date.now() - got.at;
	const grown = band !== void 0 && got.band !== void 0 && band > got.band;
	return sameWeights && complete && !grown && age < live.values.cacheTtlMs ? got.response : null;
}
/** Saves an answer (raw Jev answers only, so settings changes never re-run inference), and the usage it reported. */
function writeCached(key, response, band) {
	return chrome.storage.local.set({
		[`v:${key}`]: {
			at: Date.now(),
			response,
			band
		},
		...response.usage ? { usage: response.usage } : {}
	});
}
//#endregion
//#region src/background/judgeRequest.ts
async function sendOnce(job, id, attempt) {
	const backoffMs = live.values.baseBackoffMs * 2 ** attempt;
	try {
		noteRequestStart();
		const res = await fetch(`${API_BASE}/judge`, {
			method: "POST",
			signal: AbortSignal.timeout(live.values.requestTimeoutMs),
			headers: {
				"content-type": "application/json",
				"x-install-id": id
			},
			body: JSON.stringify({
				network: NETWORK,
				postText: job.text,
				surfaceStats: job.stats,
				nativeId: job.nativeId,
				engagement: job.engagement
			})
		});
		if (!res.ok) return await interpretFailure(res, backoffMs);
		const response = await res.json();
		learnPolicy(response.policy);
		learnWeightsVersion(response.weightsVersion);
		learnManifestVersion(response.manifestVersion);
		await writeCached(job.key, response, job.engagement ? engagementBand(job.engagement) : void 0);
		return {
			kind: "ok",
			response
		};
	} catch (e) {
		return {
			kind: "retry",
			error: describeNetworkError(e),
			pauseMs: backoffMs
		};
	}
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** Asks the server to check a post, retrying what is worth retrying. Any failure leaves the post alone (null). */
async function requestVerdict(job) {
	const id = await installId();
	updateTab(job.tabId, (s) => ({
		...s,
		sent: s.sent + 1
	}));
	let lastError = "unknown error";
	let rateWaits = 0;
	for (let attempt = 0; attempt < live.values.maxAttempts; attempt++) {
		const r = await sendOnce(job, id, attempt);
		if (r.kind === "ok") return r.response;
		lastError = r.error;
		if (r.kind === "stop") break;
		if (r.kind === "rate" && rateWaits++ < live.values.maxRateLimitWaits) {
			pauseFor(r.waitMs);
			await sleep(pausedForMs() + 25);
			attempt--;
			continue;
		}
		if (attempt < live.values.maxAttempts - 1) await sleep(r.pauseMs);
	}
	updateTab(job.tabId, (s) => ({
		...s,
		errors: s.errors + 1,
		lastError
	}));
	return null;
}
//#endregion
//#region src/background/queue.ts
var queue = [];
var pending = /* @__PURE__ */ new Map();
var inFlight = 0;
var pumpTimer;
/** Queues a post for checking. The same post asked for twice shares one request. */
function enqueue(job) {
	return new Promise((resolve) => {
		const existing = pending.get(job.key);
		if (existing) {
			existing.priority = Math.min(existing.priority, job.priority);
			existing.resolvers.push(resolve);
			return;
		}
		const j = {
			...job,
			resolvers: [resolve]
		};
		pending.set(job.key, j);
		queue.push(j);
		pump();
	});
}
/**
* The page tells us where its posts are now. A post still waiting can be re-ranked (nearest to the viewport first) or, when
* the user has scrolled far past it, dropped: it never costs a check, and it is asked for again if it scrolls back.
* Requests already in flight are left alone.
*/
function prioritize(items) {
	const by = new Map(items.map((i) => [i.urn, i.priority]));
	for (const job of [...queue]) {
		if (!by.has(job.urn)) continue;
		const priority = by.get(job.urn);
		if (priority === null || priority === void 0) {
			queue.splice(queue.indexOf(job), 1);
			pending.delete(job.key);
			job.resolvers.forEach((res) => res(null));
		} else job.priority = priority;
	}
}
/** Starts waiting requests while the policy allows. */
function pump() {
	while (inFlight < currentPolicy().maxConcurrent && queue.length) {
		const wait = startDelay();
		if (wait > 0) {
			clearTimeout(pumpTimer);
			pumpTimer = setTimeout(pump, wait + 25);
			return;
		}
		queue.sort((a, b) => a.priority - b.priority);
		const job = queue.shift();
		inFlight++;
		requestVerdict(job).then((r) => {
			inFlight--;
			pending.delete(job.key);
			job.resolvers.forEach((res) => res(r));
			pump();
		});
	}
}
onPolicyChange(pump);
//#endregion
//#region src/background/stats.ts
var serial = createSerial();
/** Counts a hidden or flagged post. Writes are serialized to avoid lost updates. */
function recordStat(kind, urn) {
	return serial(async () => {
		const next = record(await loadStats(), kind, urn, /* @__PURE__ */ new Date());
		await chrome.storage.local.set({ stats: next });
		await refreshBadge();
		return statsReply(next);
	});
}
//#endregion
//#region src/shared/labelNormalize.ts
/** Earlier builds stored "slop" / "not-slop"; map them onto the three-way vote. */
function normalizeVote(v) {
	if (v === "no" || v === "maybe" || v === "probably") return v;
	if (v === "slop") return "probably";
	if (v === "not-slop") return "no";
	return null;
}
function normalizeRecord(r) {
	const rec = r;
	const label = normalizeVote(rec?.label);
	if (!rec || !label || typeof rec.urn !== "string" || !rec.verdict) return null;
	return {
		...rec,
		label
	};
}
//#endregion
//#region src/shared/labels.ts
/** Votes live in this browser (chrome.storage.local), one key per post, and are mirrored to a file by the collector. */
var key = (urn) => `label:${urn}`;
var writeLabel = (rec) => chrome.storage.local.set({ [key(rec.urn)]: rec });
var clearLabel = (urn) => chrome.storage.local.remove(key(urn));
//#endregion
//#region src/background/labelSync.ts
/** A rejection that retrying won't fix. 408 and 429 are transient. */
var permanent = (status) => status >= 400 && status < 500 && status !== 408 && status !== 429;
function createLabelSync(d) {
	const now = d.now ?? Date.now;
	const OUTBOX = d.outboxKey ?? "labelOutbox";
	const STATUS = d.statusKey ?? "labelSyncStatus";
	const name = d.name ?? "collector";
	const serial = createSerial();
	const outbox = async () => await d.get(OUTBOX) ?? [];
	const status = async () => await d.get(STATUS) ?? {
		lastOk: null,
		lastError: null
	};
	async function report() {
		const s = await status();
		return {
			pending: (await outbox()).length,
			lastOk: s.lastOk,
			lastError: s.lastError,
			endpoint: d.endpoint
		};
	}
	/** Sends one event. A permanent rejection is recorded and the event skipped; a transient failure throws so the queue keeps it. */
	async function deliver(e, st) {
		const body = d.toBody ? d.toBody(e) : e;
		if (body === null) return;
		const res = await d.fetch(`${d.endpoint}${d.path ?? "/label"}`, {
			method: "POST",
			headers: {
				"content-type": "application/json",
				...d.headers ? await d.headers() : {}
			},
			body: JSON.stringify(body)
		});
		if (res.ok) {
			st.lastOk = now();
			st.lastError = null;
		} else if (permanent(res.status)) st.lastError = `${name} rejected an event (${res.status}); skipped it`;
		else throw new Error(`${name} answered ${res.status}`);
	}
	const describe = (e) => e instanceof TypeError ? `${name} not reachable at ${d.endpoint}${d.unreachableHint ? `: ${d.unreachableHint}` : ""}` : e instanceof Error ? e.message : String(e);
	/** Sends queued events oldest-first; stops at the first transient failure and keeps the rest. */
	const flush = () => serial(async () => {
		let box = await outbox();
		const st = await status();
		while (box.length) {
			try {
				await deliver(box[0], st);
			} catch (e) {
				st.lastError = describe(e);
				await d.set(STATUS, st);
				return report();
			}
			box = box.slice(1);
			await d.set(OUTBOX, box);
			await d.set(STATUS, st);
		}
		return report();
	});
	return {
		/** Queue an event and try to send it right away. */
		enqueue: (e) => serial(async () => {
			await d.set(OUTBOX, [...await outbox(), e].slice(-500));
		}).then(flush),
		flush,
		status: () => serial(report)
	};
}
//#endregion
//#region src/background/votes.ts
var storageIo = {
	get: async (k) => (await chrome.storage.local.get(k))[k],
	set: (k, v) => chrome.storage.local.set({ [k]: v })
};
var fileSync = null;
var serverSync = createLabelSync({
	...storageIo,
	fetch: (url, init) => fetch(url, init),
	endpoint: SERVER_URL,
	path: "/api/v1/vote",
	outboxKey: "voteOutbox",
	statusKey: "voteSyncStatus",
	name: "Slop Mop server",
	headers: async () => ({ "x-install-id": await installId() }),
	toBody: (e) => e.network && e.contentId ? {
		network: e.network,
		contentId: e.contentId,
		vote: e.label
	} : null
});
/** Sharing is best-effort and never makes a vote wait on the network. */
var share = (event) => void Promise.all([fileSync?.enqueue(event), serverSync.enqueue(event)]).catch(() => void 0);
/** Saves a vote in the browser, then shares it in the background. */
async function saveVote(record) {
	await writeLabel(record);
	share(record);
}
/** Clears a vote, telling the server which post it was (from the stored vote). */
async function clearVote(urn) {
	const prev = normalizeRecord((await chrome.storage.local.get(`label:${urn}`))[`label:${urn}`]);
	await clearLabel(urn);
	share({
		urn,
		label: null,
		at: Date.now(),
		network: prev?.network,
		contentId: prev?.contentId
	});
}
/** The developer file sync's queue and status; null in a normal build, where there is none. */
var syncLabels = () => fileSync ? fileSync.flush() : null;
var labelSyncStatus = () => fileSync ? fileSync.status() : null;
/** Retry anything waiting from earlier (called when the browser starts). */
function flushVotes() {
	fileSync?.flush();
	serverSync.flush();
}
//#endregion
//#region src/background/index.ts
/** Answers a judge request from the saved verdict, or queues a check with the server. Any failure leaves the post alone (null). */
async function judge(m, tabId) {
	const s = await getSettings();
	if (!s.enabled || !s.acknowledged) return null;
	const key = await cacheKey(m.text);
	const cached = await readCached(key, m.engagement ? engagementBand(m.engagement) : void 0);
	if (cached) {
		updateTab(tabId, (t) => ({
			...t,
			cached: t.cached + 1
		}));
		return cached;
	}
	const held = await blockedHold() ?? await dailyLimitHold();
	if (held) {
		updateTab(tabId, (t) => ({
			...t,
			errors: t.errors + 1,
			lastError: held.message
		}));
		return null;
	}
	return enqueue({
		key,
		urn: m.urn,
		text: m.text,
		stats: m.stats,
		priority: m.priority,
		tabId,
		nativeId: m.nativeId,
		engagement: m.engagement
	});
}
watchManifest();
/** What the extension does for each message from the page and the popup. */
var handlers = {
	judge: (m, tabId) => judge(m, tabId),
	prioritize: (m) => prioritize(m.items),
	record: (m) => recordStat(m.kind, m.urn),
	getStats: async () => statsReply(await loadStats()),
	pageStart: async (_m, tabId) => {
		await updateTab(tabId, () => blank());
		refreshManifestIfStale();
	},
	debug: (m, tabId) => updateTab(tabId, (s) => ({
		...s,
		detected: m.detected,
		ads: m.ads,
		own: m.own,
		skipped: m.skipped
	})),
	getDebug: (m) => m.tabId === void 0 ? allTabs() : getTab(m.tabId),
	myDebug: (_m, tabId) => tabId === void 0 ? blank() : getTab(tabId),
	vote: (m) => saveVote(m.record),
	unvote: (m) => clearVote(m.urn),
	syncLabels: () => syncLabels(),
	getLabelSync: () => labelSyncStatus()
};
chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
	const handler = handlers[m.type];
	Promise.resolve().then(() => handler(m, sender.tab?.id)).then(sendResponse, () => sendResponse(m.type === "judge" ? null : void 0));
	return true;
});
chrome.storage.onChanged.addListener((changes, area) => {
	if (area === "sync" && changes.settings) refreshBadge();
});
chrome.tabs.onRemoved.addListener((id) => void chrome.storage.session.remove(tabKey(id)));
chrome.runtime.onInstalled.addListener((d) => {
	refreshBadge();
	if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
});
chrome.runtime.onStartup.addListener(() => {
	refreshBadge();
	flushVotes();
});
//#endregion
