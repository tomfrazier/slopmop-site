import { n as updateSettings, t as getSettings } from "./settings-D5A_e2ky.js";
import { n as $, t as send } from "./messages-BUwlk7hc.js";
//#region src/shared/manifest.ts
/**
* The fixed values the extension runs on. The server publishes them as a manifest (see the server's manifest.ts) that the
* extension keeps for a day and refreshes when an answer reports a newer version, so any of them can change without a new
* release. These defaults are what applies before the first manifest arrives, and for any value the manifest leaves out.
*/
var SECOND_MS = 1e3;
var HOUR_MS = 60 * (60 * SECOND_MS);
var DAY_MS = 24 * HOUR_MS;
var DEFAULT_MANIFEST = {
	requestTimeoutMs: 15 * SECOND_MS,
	maxAttempts: 3,
	baseBackoffMs: 500,
	maxRetryPauseMs: 8 * SECOND_MS,
	maxRateLimitWaits: 5,
	maxRateLimitPauseS: 60,
	defaultRateLimitPauseS: 5,
	blockedRecheckMs: HOUR_MS,
	cacheTtlMs: 7 * DAY_MS,
	engagementBandGrowth: 1.25,
	lookaheadPx: 1500,
	dropBeyondPx: 200,
	scrollHintMs: 200,
	rescanDelayMs: 250,
	postRetryDelaysMs: [
		8 * SECOND_MS,
		30 * SECOND_MS,
		90 * SECOND_MS
	],
	minChars: 200,
	minOwnChars: 60,
	yellowFraction: .6,
	minMeanConfidence: .25,
	aiDampen: .35,
	strongSign: .4,
	flaggedSign: .2,
	displayPossibly: 40,
	displayLikely: 70,
	displayFullMultiple: 2,
	defaultDailyLimit: 250
};
var MANIFEST_KEY = "manifest";
/** The values in force in this script. Read `live.values.x` where the value is used, never at import time. */
var live = {
	values: { ...DEFAULT_MANIFEST },
	thresholds: null,
	version: null
};
var okThresholds = (t) => {
	const x = t;
	const ok = (n) => typeof n === "number" && n > 0 && n <= 1;
	return !!x && ok(x.aggressive) && ok(x.moderate) && ok(x.mild) && x.aggressive <= x.moderate && x.moderate <= x.mild;
};
/** Keeps only values of the right kind, so a bad manifest can never break a setting. */
function sane(values) {
	const out = {};
	for (const [key, def] of Object.entries(DEFAULT_MANIFEST)) {
		const v = values?.[key];
		if (Array.isArray(def)) {
			if (Array.isArray(v) && v.length > 0 && v.every((n) => typeof n === "number" && Number.isFinite(n) && n > 0)) out[key] = v;
		} else if (typeof v === "number" && Number.isFinite(v) && v > 0) out[key] = v;
	}
	return out;
}
/** Makes a stored manifest the one in force (or the defaults, when there is none or it is unusable). */
function applyManifest(stored) {
	const s = stored;
	live.values = {
		...DEFAULT_MANIFEST,
		...sane(s?.values)
	};
	live.thresholds = okThresholds(s?.thresholds) ? s.thresholds : null;
	live.version = typeof s?.version === "string" ? s.version : null;
}
/** Loads the saved manifest and follows changes to it. Call once when a script starts. */
async function watchManifest() {
	applyManifest((await chrome.storage.local.get(MANIFEST_KEY))[MANIFEST_KEY]);
	chrome.storage.onChanged.addListener((changes, area) => {
		if (area === "local" && changes["manifest"]) applyManifest(changes[MANIFEST_KEY].newValue);
	});
}
//#endregion
//#region src/popup/settingsPanel.ts
var modeButtons = [...document.querySelectorAll("[data-mode]")];
var NOTES = {
	hide: "Posts that look like slop fold into a small paper strip. Click to unfold.",
	highlight: "Nothing is hidden. Possibly slop: yellow border. Likely slop: red border."
};
var sensButtons = [...document.querySelectorAll("[data-sens]")];
var SENS_NOTES = {
	mild: "Only the clearest slop. Fewest false alarms.",
	moderate: "The default balance.",
	aggressive: "Catches more, and is wrong more often."
};
function paint(s) {
	$("enabled").checked = s.enabled;
	$("main").classList.toggle("disabled", !s.enabled);
	modeButtons.forEach((b) => b.setAttribute("aria-checked", String(b.dataset.mode === s.mode)));
	$("mode-note").textContent = NOTES[s.mode];
	sensButtons.forEach((b) => b.setAttribute("aria-checked", String(b.dataset.sens === s.sensitivity)));
	$("sens-note").textContent = SENS_NOTES[s.sensitivity];
}
/** The on/off switch, the Hide/Highlight choice and the sensitivity choice. Returns the settings as they were loaded. */
async function mountSettingsPanel() {
	let settings = await getSettings();
	/** Saves a change, then redraws from what was saved. */
	const change = async (patch) => {
		settings = await updateSettings(patch);
		paint(settings);
		return settings;
	};
	paint(settings);
	$("enabled").addEventListener("change", async (e) => {
		const box = e.target;
		if (box.checked && !settings.acknowledged) {
			box.checked = false;
			await chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
			window.close();
			return;
		}
		await change({ enabled: box.checked });
	});
	modeButtons.forEach((b) => b.addEventListener("click", () => void change({ mode: b.dataset.mode })));
	sensButtons.forEach((b) => b.addEventListener("click", () => void change({ sensitivity: b.dataset.sens })));
	return settings;
}
//#endregion
//#region src/popup/statsPanel.ts
/** Hidden and flagged counts. */
async function paintStats() {
	const r = await send({ type: "getStats" });
	$("s-today").textContent = String(r.hidden.today);
	$("s-week").textContent = String(r.hidden.week);
	$("s-month").textContent = String(r.hidden.month);
	$("s-total").textContent = String(r.hidden.total);
	$("flagged").textContent = r.flagged.total ? `${r.flagged.today} flagged today · ${r.flagged.total} all time (highlight mode)` : "";
}
var timeOf = (iso) => new Date(iso).toLocaleTimeString([], {
	hour: "numeric",
	minute: "2-digit"
});
/** Checks used today out of the server's daily cap, from the counts every server answer carries. */
async function paintUsage() {
	const { usage, dailyLimit, blocked } = await chrome.storage.local.get([
		"usage",
		"dailyLimit",
		"blocked"
	]);
	const now = Date.now();
	const used = !usage || Date.parse(usage.resetsAt) <= now ? 0 : usage.used;
	const limit = usage?.limit ?? live.values.defaultDailyLimit;
	const disabled = !!blocked && blocked.until > now;
	const full = disabled || !!dailyLimit && dailyLimit.until > now;
	const shown = full ? limit : used;
	$("usage-n").textContent = String(shown);
	$("usage-of").textContent = `of ${limit}`;
	$("usage-bar").style.width = `${Math.min(100, shown / limit * 100)}%`;
	$("usage-n").closest(".usage-box").classList.toggle("full", full);
	if (disabled) return void ($("usage-note").textContent = blocked.message);
	const resets = usage ? timeOf(usage.resetsAt) : null;
	$("usage-note").textContent = full && resets ? `Daily limit reached. Checking resumes at ${resets}.` : `Each new post checked uses one. The count resets daily${resets ? ` (next: ${resets})` : ""}.`;
}
//#endregion
//#region src/popup/popup.ts
/** The toolbar popup: settings on top, then how much it has done. Developer options live on the extension's settings page. */
async function main() {
	await watchManifest();
	await mountSettingsPanel();
	paintStats();
	paintUsage();
	chrome.storage.onChanged.addListener(() => {
		paintStats();
		paintUsage();
	});
	document.getElementById("open-settings").addEventListener("click", (e) => {
		e.preventDefault();
		chrome.runtime.openOptionsPage();
	});
}
main();
//#endregion
