import { n as updateSettings } from "./settings-D5A_e2ky.js";
//#region src/onboarding/onboarding.ts
var ack = document.getElementById("ack");
var go = document.getElementById("go");
ack.addEventListener("change", () => go.disabled = !ack.checked);
go.addEventListener("click", async () => {
	await updateSettings({
		acknowledged: true,
		enabled: true
	});
	document.getElementById("done").textContent = "Enabled. Open your LinkedIn feed.";
	go.disabled = true;
});
//#endregion
