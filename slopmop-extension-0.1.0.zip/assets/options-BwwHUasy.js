import { n as updateSettings, t as getSettings } from "./settings-D5A_e2ky.js";
import { n as $, r as POLL_INTERVAL_MS, t as send } from "./messages-BUwlk7hc.js";
//#region src/options/debugPanel.ts
var DEBUG_COUNTERS = [
	"sent",
	"cached",
	"errors",
	"detected",
	"ads",
	"own",
	"skipped"
];
/** What the open LinkedIn tabs have sent and seen since they loaded (the Debug switch). */
async function paintDebug(on) {
	$("debug-panel").hidden = !on;
	if (!on) return;
	const d = await send({ type: "getDebug" });
	if (!d) return;
	for (const k of DEBUG_COUNTERS) $(`d-${k}`).textContent = String(d[k]);
	$("d-error").textContent = d.lastError ? `Last error: ${d.lastError}` : "";
}
//#endregion
//#region src/shared/labelNormalize.ts
/** Earlier builds stored "slop" / "not-slop"; map them onto the three-way vote. */
function normalizeVote(v) {
	if (v === "no" || v === "maybe" || v === "probably") return v;
	if (v === "slop") return "probably";
	if (v === "not-slop") return "no";
	return null;
}
function normalizeRecord(r) {
	const rec = r;
	const label = normalizeVote(rec?.label);
	if (!rec || !label || typeof rec.urn !== "string" || !rec.verdict) return null;
	return {
		...rec,
		label
	};
}
//#endregion
//#region src/shared/labels.ts
async function allLabels() {
	const all = await chrome.storage.local.get(null);
	return Object.entries(all).filter(([k]) => k.startsWith("label:")).map(([, v]) => normalizeRecord(v)).filter((r) => r !== null).sort((a, b) => a.at - b.at);
}
async function clearAllLabels() {
	const all = await chrome.storage.local.get(null);
	await chrome.storage.local.remove(Object.keys(all).filter((k) => k.startsWith("label:")));
}
//#endregion
//#region src/options/votesPanel.ts
var URL_LIFETIME_MS = 1e3;
/** The vote count, and (in developer builds with a file collector) whether votes are waiting to be written. */
async function paintLabels() {
	const ls = await allLabels();
	const count = (v) => ls.filter((l) => l.label === v).length;
	$("lbl-count").textContent = `${ls.length} (${count("no")} no · ${count("maybe")} maybe · ${count("probably")} probably)`;
	$("lbl-export").disabled = ls.length === 0;
	$("lbl-clear").disabled = ls.length === 0;
	const st = await send({ type: "getLabelSync" });
	const el = $("lbl-sync");
	el.hidden = !st;
	$("lbl-sync-now").hidden = !st;
	$("lbl-note-main").textContent = st ? "Hover a post's mop icon and vote No / Maybe / Probably. Saved here, shared with the Slop Mop server, and appended to a file by the local collector." : "Vote No / Maybe / Probably from a post's mop icon. Votes are saved here and shared with the Slop Mop server. Export them to tune thresholds.";
	if (!st) return;
	const time = st.lastOk ? new Date(st.lastOk).toLocaleTimeString() : null;
	const waiting = st.pending !== 0;
	el.className = waiting ? "sync warn" : "sync ok";
	el.textContent = waiting ? `${st.pending} vote${st.pending === 1 ? "" : "s"} waiting to be written. ${st.lastError ?? ""}` : time ? `File up to date (last write ${time}).` : "Nothing to write yet.";
}
/** Saves the votes as a JSON file for `npm run tune`. */
async function exportLabels() {
	const labels = await allLabels();
	const blob = new Blob([JSON.stringify({
		version: 1,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		settings: await getSettings(),
		labels
	}, null, 2)], { type: "application/json" });
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = `slopmop-labels-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
	a.click();
	setTimeout(() => URL.revokeObjectURL(a.href), URL_LIFETIME_MS);
	$("lbl-note").textContent = `Exported ${labels.length}. Then: npm run tune -- <that file>`;
}
/** Export, sync and clear buttons for the saved votes. */
function mountVotesPanel() {
	$("lbl-export").addEventListener("click", () => void exportLabels());
	$("lbl-sync-now").addEventListener("click", async () => {
		await send({ type: "syncLabels" });
		paintLabels();
	});
	$("lbl-clear").addEventListener("click", async () => {
		if (!confirm("Delete all tuning labels stored in this browser?")) return;
		await clearAllLabels();
		paintLabels();
	});
	paintLabels();
}
//#endregion
//#region src/options/devPanel.ts
/** The Debug switch and its panel, and the saved-votes list. Keeps itself fresh while the page is open. */
function mountDevPanel(settings) {
	const debug = $("debug");
	debug.checked = settings.debug;
	paintDebug(settings.debug);
	debug.addEventListener("change", async () => {
		await updateSettings({ debug: debug.checked });
		paintDebug(debug.checked);
	});
	mountVotesPanel();
	setInterval(() => {
		paintDebug(debug.checked);
		paintLabels();
	}, POLL_INTERVAL_MS);
}
//#endregion
//#region src/options/options.ts
/** The extension's settings page: developer options (debug mode, saved votes). */
getSettings().then(mountDevPanel);
//#endregion
