//#region src/shared/pageDom.ts
/** An element of popup.html by id. */
var $ = (id) => document.getElementById(id);
/** How often the developer panels refresh while the popup is open. */
var POLL_INTERVAL_MS = 1e3;
//#endregion
//#region src/shared/messages.ts
var isInvalidated = (e) => e instanceof Error && /context invalidated/i.test(e.message);
/** Sends a message to the background worker. If the extension has vanished it stops the page script quietly instead of throwing. */
async function send(m) {
	try {
		return await chrome.runtime.sendMessage(m);
	} catch (e) {
		if (!isInvalidated(e)) throw e;
		return;
	}
}
//#endregion
export { $ as n, POLL_INTERVAL_MS as r, send as t };
