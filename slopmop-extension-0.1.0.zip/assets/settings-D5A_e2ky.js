//#region src/shared/types.ts
var DEFAULT_SETTINGS = {
	enabled: false,
	mode: "hide",
	sensitivity: "moderate",
	acknowledged: false,
	debug: false
};
//#endregion
//#region src/shared/settings.ts
async function getSettings() {
	const { settings } = await chrome.storage.sync.get("settings");
	return {
		...DEFAULT_SETTINGS,
		...settings
	};
}
async function updateSettings(patch) {
	const next = {
		...await getSettings(),
		...patch
	};
	if (!next.acknowledged) next.enabled = false;
	await chrome.storage.sync.set({ settings: next });
	return next;
}
//#endregion
export { updateSettings as n, getSettings as t };
