(function() {
	//#region src/shared/manifest.ts
	/**
	* The fixed values the extension runs on. The server publishes them as a manifest (see the server's manifest.ts) that the
	* extension keeps for a day and refreshes when an answer reports a newer version, so any of them can change without a new
	* release. These defaults are what applies before the first manifest arrives, and for any value the manifest leaves out.
	*/
	var SECOND_MS$1 = 1e3;
	var HOUR_MS$1 = 60 * (60 * SECOND_MS$1);
	var DAY_MS$1 = 24 * HOUR_MS$1;
	var DEFAULT_MANIFEST = {
		requestTimeoutMs: 15 * SECOND_MS$1,
		maxAttempts: 3,
		baseBackoffMs: 500,
		maxRetryPauseMs: 8 * SECOND_MS$1,
		maxRateLimitWaits: 5,
		maxRateLimitPauseS: 60,
		defaultRateLimitPauseS: 5,
		blockedRecheckMs: HOUR_MS$1,
		cacheTtlMs: 7 * DAY_MS$1,
		engagementBandGrowth: 1.25,
		lookaheadPx: 1500,
		dropBeyondPx: 200,
		scrollHintMs: 200,
		rescanDelayMs: 250,
		postRetryDelaysMs: [
			8 * SECOND_MS$1,
			30 * SECOND_MS$1,
			90 * SECOND_MS$1
		],
		minChars: 200,
		minOwnChars: 60,
		yellowFraction: .6,
		minMeanConfidence: .25,
		aiDampen: .35,
		strongSign: .4,
		flaggedSign: .2,
		displayPossibly: 40,
		displayLikely: 70,
		displayFullMultiple: 2,
		defaultDailyLimit: 250
	};
	var MANIFEST_KEY = "manifest";
	/** The values in force in this script. Read `live.values.x` where the value is used, never at import time. */
	var live = {
		values: { ...DEFAULT_MANIFEST },
		thresholds: null,
		version: null
	};
	var okThresholds = (t) => {
		const x = t;
		const ok = (n) => typeof n === "number" && n > 0 && n <= 1;
		return !!x && ok(x.aggressive) && ok(x.moderate) && ok(x.mild) && x.aggressive <= x.moderate && x.moderate <= x.mild;
	};
	/** Keeps only values of the right kind, so a bad manifest can never break a setting. */
	function sane(values) {
		const out = {};
		for (const [key, def] of Object.entries(DEFAULT_MANIFEST)) {
			const v = values?.[key];
			if (Array.isArray(def)) {
				if (Array.isArray(v) && v.length > 0 && v.every((n) => typeof n === "number" && Number.isFinite(n) && n > 0)) out[key] = v;
			} else if (typeof v === "number" && Number.isFinite(v) && v > 0) out[key] = v;
		}
		return out;
	}
	/** Makes a stored manifest the one in force (or the defaults, when there is none or it is unusable). */
	function applyManifest(stored) {
		const s = stored;
		live.values = {
			...DEFAULT_MANIFEST,
			...sane(s?.values)
		};
		live.thresholds = okThresholds(s?.thresholds) ? s.thresholds : null;
		live.version = typeof s?.version === "string" ? s.version : null;
	}
	/** Loads the saved manifest and follows changes to it. Call once when a script starts. */
	async function watchManifest() {
		applyManifest((await chrome.storage.local.get(MANIFEST_KEY))[MANIFEST_KEY]);
		chrome.storage.onChanged.addListener((changes, area) => {
			if (area === "local" && changes["manifest"]) applyManifest(changes[MANIFEST_KEY].newValue);
		});
	}
	//#endregion
	//#region src/shared/messages.ts
	/**
	* False once the extension was reloaded, updated or removed while this page kept running its old script: from then on every
	* chrome.* call throws "Extension context invalidated". A page can't be given the new script without a refresh.
	*/
	var extensionAlive = () => !!chrome.runtime?.id;
	var isInvalidated = (e) => e instanceof Error && /context invalidated/i.test(e.message);
	var onGone = () => {};
	/** Registers what to do (once) when a message finds the extension gone. */
	var whenExtensionGone = (fn) => void (onGone = fn);
	/** Sends a message to the background worker. If the extension has vanished it stops the page script quietly instead of throwing. */
	async function send(m) {
		try {
			return await chrome.runtime.sendMessage(m);
		} catch (e) {
			if (!isInvalidated(e)) throw e;
			onGone();
			return;
		}
	}
	//#endregion
	//#region src/shared/types.ts
	var DEFAULT_SETTINGS = {
		enabled: false,
		mode: "hide",
		sensitivity: "moderate",
		acknowledged: false,
		debug: false
	};
	//#endregion
	//#region src/shared/settings.ts
	async function getSettings() {
		const { settings } = await chrome.storage.sync.get("settings");
		return {
			...DEFAULT_SETTINGS,
			...settings
		};
	}
	//#endregion
	//#region src/content/queueHints.ts
	/** How far the observer looks beyond the viewport, so posts are checked before they scroll into view. */
	var rootMarginPx = () => live.values.lookaheadPx;
	/** 0 while any part of the post is in view, else how many pixels it is above or below the viewport. */
	function viewportDistance(rect, viewportHeight) {
		if (rect.bottom < 0) return -rect.bottom;
		if (rect.top > viewportHeight) return rect.top - viewportHeight;
		return 0;
	}
	/**
	* What to tell the queue about a waiting post: its distance (nearest is served first), or null to drop it because the user
	* has scrolled well outside the range in which posts are requested. Dropping only beyond that range guarantees the
	* IntersectionObserver reports it again on the way back, so a dropped post is never stranded.
	*/
	function queueHint(rect, viewportHeight) {
		const d = viewportDistance(rect, viewportHeight);
		return d > rootMarginPx() + live.values.dropBeyondPx ? null : d;
	}
	//#endregion
	//#region src/content/state.ts
	/** What the content script knows right now. One page, one script, so this is plain shared state. */
	var state = {
		settings: DEFAULT_SETTINGS,
		lastStats: null,
		/** The signed-in user's name, so their own posts can be recognised. */
		ownName: null,
		learnedName: false
	};
	/** The scoring parameters this page passes to decide(): what the server's manifest says (its thresholds only once it has sent them). */
	var scoringParams = () => ({
		...live.thresholds ? { thresholds: live.thresholds } : {},
		yellowFraction: live.values.yellowFraction,
		minMeanConfidence: live.values.minMeanConfidence,
		aiDampen: live.values.aiDampen
	});
	/** Posts by id, and by the element that holds them (LinkedIn recycles elements, so both are kept). */
	var posts = /* @__PURE__ */ new Map();
	var byEl = /* @__PURE__ */ new WeakMap();
	/** Posts the user unfolded (until they choose "Hide post again"). */
	var restored = /* @__PURE__ */ new Set();
	/** Counts of what has been seen on this page load, for the popup's debug panel. */
	var seen = {
		detected: 0,
		ads: 0,
		own: 0,
		skipped: 0
	};
	var counted = /* @__PURE__ */ new Set();
	/** True while the extension is switched on and the user has accepted the research notice. */
	var active = () => state.settings.enabled && state.settings.acknowledged;
	/**
	* Some modules must trigger a redraw but can't import the drawing code without importing each other in a circle (drawing
	* needs voting, voting needs analysis, analysis needs to redraw). index.ts sets this once at startup.
	*/
	var hooks = {
		render: (_t) => {},
		/** Stops the script and takes down what it drew (the extension was reloaded or removed under this page). */
		shutdown: () => {}
	};
	//#endregion
	//#region src/content/scrollHints.ts
	/**
	* While scrolling fast the queue can fall behind. Keep it honest: rank waiting posts by how near they are to the viewport
	* right now (not where they were when they were queued), and drop those left far behind or ahead so they don't use up
	* checks. Anything dropped is outside the observer's range, so it is requested again when it scrolls back into it.
	*/
	function reprioritize() {
		const items = [];
		for (const t of posts.values()) {
			if (!t.pending || !t.el.isConnected) continue;
			const priority = queueHint(t.el.getBoundingClientRect(), window.innerHeight);
			if (priority === null) t.cancelled = true;
			items.push({
				urn: t.urn,
				priority
			});
		}
		if (items.length) send({
			type: "prioritize",
			items
		}).catch(() => void 0);
	}
	/** Tells the extension where the posts are as the user scrolls (throttled). */
	function watchScrolling() {
		let timer = 0;
		document.addEventListener("scroll", () => {
			if (timer) return;
			timer = window.setTimeout(() => {
				timer = 0;
				reprioritize();
			}, live.values.scrollHintMs);
		}, {
			capture: true,
			passive: true
		});
	}
	//#endregion
	//#region src/shared/composite.ts
	/**
	* The weighted mean of the tell answers. The server's composite wins unless the caller supplied weights to try (offline
	* tuning), in which case it is computed here. Null when there is nothing to weigh.
	*/
	function composite(r, P, opts) {
		const server = opts.params?.weights === void 0 && r.tellMean !== void 0 && Array.isArray(r.tellRank) ? {
			mean: r.tellMean,
			rank: r.tellRank
		} : null;
		const ids = (server ? server.rank : Object.keys(P.weights)).filter((id) => r.dimensions[id]);
		if (ids.length === 0) return null;
		const weightOf = (id) => P.weights[id] * Math.max(0, r.dimensions[id].confidence) ** CONFIDENCE_POWER;
		const totalWeight = server ? 0 : ids.reduce((sum, id) => sum + weightOf(id), 0);
		const mean = server ? server.mean : totalWeight > 0 ? ids.reduce((sum, id) => sum + weightOf(id) * r.dimensions[id].value, 0) / totalWeight : 0;
		const tells = ids.map((id) => ({
			id,
			value: r.dimensions[id].value,
			confidence: r.dimensions[id].confidence,
			...server ? {} : {
				weight: weightOf(id),
				contrib: totalWeight > 0 ? weightOf(id) * r.dimensions[id].value / totalWeight : 0
			}
		}));
		if (!server) tells.sort((a, b) => (b.contrib ?? 0) - (a.contrib ?? 0));
		return {
			mean,
			meanConfidence: ids.reduce((sum, id) => sum + r.dimensions[id].confidence, 0) / ids.length,
			tells
		};
	}
	/** How much Jev's confidence counts toward a tell's weight: weight x confidence^0.5 (the server does the same). */
	var CONFIDENCE_POWER = .5;
	/** How many tells stand out: they reach the breakout value with enough confidence behind them. */
	var breakouts = (tells, c) => tells.filter((t) => t.value >= c.breakout && t.confidence >= c.minConfidence).length;
	/** True when some tell stands out but too few to corroborate each other (none standing out is broad and mild, and is left as it is). */
	var isAlone = (standing, c) => standing > 0 && standing < c.needed;
	/** Where the score lands: nothing, "possibly" (yellow) or "likely" (red), and a plain-language sentence saying why. */
	function classify(input) {
		const { score, lowConfidence, threshold, yellowAt, mode } = input;
		if (lowConfidence) return {
			level: "none",
			outcome: "Jev wasn't confident enough to call this one, so it isn't flagged."
		};
		if (score >= threshold) return {
			level: "red",
			outcome: mode === "hide" ? "This reads like AI slop, so it was hidden." : "This reads like AI slop."
		};
		if (score >= yellowAt) return {
			level: "yellow",
			outcome: "This has some hallmarks of AI slop, but isn't clear-cut."
		};
		return {
			level: "none",
			outcome: "Nothing here stands out as AI slop."
		};
	}
	var DEFAULT_PARAMS = {
		weights: {
			contrastFraming: 1,
			emptyEvaluation: 1,
			tradeoffFreePromises: 1,
			formalHedging: 1,
			hypeMarketing: 1,
			manneredProse: 1,
			formulaicHook: 1,
			manufacturedNarrative: 1,
			engagementBait: 1
		},
		thresholds: {
			aggressive: .1,
			moderate: .18,
			mild: .22
		},
		gain: 2,
		humanOffset: .15,
		aiDampen: .35,
		maxShield: .6,
		corroboration: {
			breakout: .5,
			minConfidence: .5,
			needed: 2,
			alone: .6
		},
		yellowFraction: .6,
		minMeanConfidence: .25
	};
	//#endregion
	//#region src/shared/engagement.ts
	var clamp01 = (n) => Math.min(1, Math.max(0, n));
	var DEFAULT_ENGAGEMENT = {
		reaction: 1,
		comment: 5,
		repost: 12,
		hollowFrom: 50,
		hollowRatio: .02,
		hollowFloor: .4
	};
	var ENGAGEMENT_LOG_SCALE = 4;
	/** The shield is half "useful to a reader" and half "people engaged with it". */
	var SHIELD_USEFUL_SHARE = .5;
	function engagementNorm(e, m = DEFAULT_ENGAGEMENT) {
		const weighted = m.reaction * e.reactions + m.comment * e.comments + m.repost * e.reposts;
		const depth = e.reactions > 0 ? (e.comments + e.reposts) / e.reactions : 1;
		const credit = e.reactions >= m.hollowFrom && depth < m.hollowRatio ? Math.max(m.hollowFloor, depth / m.hollowRatio) : 1;
		return clamp01(Math.log10(1 + weighted * credit) / ENGAGEMENT_LOG_SCALE);
	}
	/** Each step up in this is about 25% more (the manifest's engagementBandGrowth) reactions, comments and reposts together: a post is worth asking the server about again when its step changes. */
	var engagementBand = (e) => Math.round(Math.log1p(e.reactions + e.comments + e.reposts) / Math.log(live.values.engagementBandGrowth));
	//#endregion
	//#region src/shared/decide.ts
	/** The factor a post's score is multiplied by for how human-written Jev thinks it reads: 1 for a sure AI draft, 1 - dampen for a sure human one. */
	var dampenFactor = (aiLikelihood, dampen) => 1 - dampen * (1 - clamp01(aiLikelihood));
	var NOT_A_DECISION = (r) => ({
		level: "none",
		hide: false,
		score: 0,
		slop: 0,
		shield: 0,
		aiLikelihood: r?.aiLikelihood ?? 0,
		reasons: [],
		explain: null
	});
	function decide(r, engagement, mode, sensitivity, opts = {}) {
		if (!r) return NOT_A_DECISION(r);
		const P = {
			...DEFAULT_PARAMS,
			...opts.params
		};
		const c = composite(r, P, opts);
		if (!c) return NOT_A_DECISION(r);
		const human = r.dimensions.humanVoice?.value ?? 0;
		const useful = r.dimensions.usefulness?.value ?? 0;
		const eNorm = engagementNorm(engagement);
		const p = opts.params;
		const fromServer = r.slop !== void 0 && r.shield !== void 0 && p?.weights === void 0 && p?.gain === void 0 && p?.humanOffset === void 0 && p?.maxShield === void 0 && p?.corroboration === void 0;
		const readerResponse = fromServer && r.engagementNorm !== void 0 ? r.engagementNorm : eNorm;
		const standing = fromServer && r.breakouts !== void 0 ? r.breakouts : breakouts(c.tells, P.corroboration);
		const slop = fromServer ? r.slop : clamp01(c.mean * P.gain - P.humanOffset * human) * (isAlone(standing, P.corroboration) ? P.corroboration.alone : 1);
		const shieldOn = opts.shield !== false;
		const localShield = Math.min(P.maxShield, SHIELD_USEFUL_SHARE * useful + (1 - SHIELD_USEFUL_SHARE) * eNorm);
		const usefulOnly = fromServer ? r.usefulShield ?? 0 : Math.min(P.maxShield, SHIELD_USEFUL_SHARE * useful);
		const shield = !shieldOn ? usefulOnly : fromServer ? r.shield : localShield;
		const aiDampen = dampenFactor(r.aiLikelihood, P.aiDampen);
		const score = slop * (1 - shield) * aiDampen;
		const threshold = P.thresholds[sensitivity];
		const yellowAt = P.yellowFraction * threshold;
		const lowConfidence = c.meanConfidence < P.minMeanConfidence;
		const { level, outcome } = classify({
			score,
			lowConfidence,
			threshold,
			yellowAt,
			mode
		});
		const explain = {
			tells: c.tells,
			mean: c.mean,
			gain: P.gain,
			humanVoice: human,
			...fromServer ? {} : { humanOffset: P.humanOffset },
			source: fromServer ? "server" : "local",
			usefulness: useful,
			engagement: {
				...engagement,
				norm: readerResponse
			},
			shieldOn,
			maxShield: P.maxShield,
			aiLikelihood: r.aiLikelihood,
			aiDampen,
			breakouts: standing,
			meanConfidence: c.meanConfidence,
			minMeanConfidence: P.minMeanConfidence,
			lowConfidence,
			threshold,
			yellowAt,
			mode,
			sensitivity,
			outcome
		};
		return {
			level,
			hide: mode === "hide" && level === "red",
			score,
			slop,
			shield,
			aiLikelihood: r.aiLikelihood,
			reasons: c.tells.slice(0, 2).map(({ id, value }) => ({
				id,
				value
			})),
			explain
		};
	}
	/**
	* Your own posts: always coloured, never hidden. The shield keeps only its usefulness half (no reader response), so the colour
	* reflects the writing and how useful Jev finds it, not how it was received. Green = clean, yellow = some AI tells, red = likely slop.
	*/
	function decideOwn(r, sensitivity, params) {
		const d = decide(r, {
			reactions: 0,
			comments: 0,
			reposts: 0
		}, "highlight", sensitivity, {
			shield: false,
			params
		});
		return {
			...d,
			ownLevel: d.level === "red" ? "red" : d.level === "yellow" ? "yellow" : "green"
		};
	}
	//#endregion
	//#region src/shared/dom.ts
	/**
	* Tiny DOM builders. LinkedIn enforces Trusted Types, which turns `innerHTML` strings into escaped text,
	* so injected UI is built from real nodes (no HTML-string sinks).
	*/
	var SVG_NS$1 = "http://www.w3.org/2000/svg";
	function fill(el, attrs, children) {
		for (const [k, v] of Object.entries(attrs)) if (v !== void 0) el.setAttribute(k, String(v));
		for (const c of children) if (c != null) el.append(c);
		return el;
	}
	var h = (tag, attrs = {}, ...children) => fill(document.createElement(tag), attrs, children);
	var s = (tag, attrs = {}, ...children) => fill(document.createElementNS(SVG_NS$1, tag), attrs, children);
	function style(css) {
		const el = document.createElement("style");
		el.textContent = css;
		return el;
	}
	/** The Slop Mop mark from the design system: handle and head in `color`, the bristle gaps in `knockout` (the surface behind it). */
	function mopIcon(size = 20, color = "currentColor", knockout = "#FFFFFF") {
		return s("svg", {
			width: size,
			height: size,
			viewBox: "0 0 24 24",
			"aria-hidden": "true",
			focusable: "false"
		}, s("rect", {
			x: 10.6,
			y: 2,
			width: 2.8,
			height: 12,
			rx: 1.4,
			fill: color
		}), s("path", {
			d: "M5.2 13.6h13.6l-1.6 8.2H6.8z",
			fill: color
		}), s("path", {
			d: "M8.6 16.6v4.6M12 16.6v4.6M15.4 16.6v4.6",
			stroke: knockout,
			"stroke-width": 1.15,
			"stroke-linecap": "round"
		}));
	}
	//#endregion
	//#region src/shared/palette.ts
	/** The Slop Mop design system's fixed colours, for the places that paint from code (SVG attributes, inline outlines). CSS uses the tokens in tokens.css. */
	var PALETTE = {
		ink900: "#16181A",
		ink600: "#565C63",
		ink500: "#6E757D",
		ink400: "#8D949B",
		ink300: "#B2B8BE",
		ink200: "#D3D7DB",
		ink100: "#E6E9EC",
		paper000: "#FFFFFF",
		paper200: "#EFF1F3",
		mop500: "#F5B400",
		mop300: "#FFD24A",
		mop200: "#FFE9A8",
		mop900: "#7A5A00",
		red500: "#D93025",
		red200: "#F6C6C2",
		blue500: "#2F6FBF",
		blue200: "#C6DCF4"
	};
	//#endregion
	//#region src/shared/surface.ts
	var CONTRACTION = /\b\w+['’](?:t|s|re|ve|ll|d|m)\b/gi;
	/** Cheap, deterministic surface features. Known calculations stay in code; Jev gets them as facts. */
	function surfaceStats(text) {
		const wordCount = (text.match(/[\p{L}\p{N}'’-]+/gu) ?? []).length;
		const sentences = text.split(/(?<=[.!?…])\s+|\n+/).map((s) => s.trim()).filter(Boolean);
		const lengths = sentences.map((s) => (s.match(/[\p{L}\p{N}'’-]+/gu) ?? []).length);
		const mean = lengths.reduce((a, b) => a + b, 0) / (lengths.length || 1);
		const variance = lengths.reduce((a, b) => a + (b - mean) ** 2, 0) / (lengths.length || 1);
		const round = (n) => Math.round(n * 100) / 100;
		return {
			wordCount,
			sentenceCount: sentences.length,
			sentenceLengthStdDev: round(Math.sqrt(variance)),
			contractionsPer100Words: round((text.match(CONTRACTION) ?? []).length / (wordCount || 1) * 100),
			exclamationCount: (text.match(/!/g) ?? []).length,
			emDashesPer1000Words: round((text.match(/—/g) ?? []).length / (wordCount || 1) * 1e3)
		};
	}
	//#endregion
	//#region src/shared/tokens.css?inline
	var tokens_default = "/* Slop Mop design tokens, copied from the Slop Mop Design System (tokens/*.css). :host lets the same file style shadow roots. */\n:root,:host{--font-display:\"Archivo\",ui-sans-serif,system-ui,sans-serif;--font-body:\"Archivo\",ui-sans-serif,system-ui,sans-serif;--font-mono:\"JetBrains Mono\",ui-monospace,SFMono-Regular,Menlo,monospace}\n:root,:host{\n/* --- Neutral greys: plain, cool-neutral, no warm cast --- */\n--ink-900:#16181A;--ink-800:#24282B;--ink-700:#3B4045;--ink-600:#565C63;--ink-500:#6E757D;--ink-400:#8D949B;--ink-300:#B2B8BE;--ink-200:#D3D7DB;--ink-100:#E6E9EC;--ink-050:#F1F3F5;\n/* --- Surfaces --- */\n--paper-000:#FFFFFF;--paper-100:#F7F8F9;--paper-200:#EFF1F3;--paper-300:#E4E7EA;\n/* --- Mop Yellow: signal accent, used for flags and the one primary action --- */\n--mop-900:#7A5A00;--mop-700:#B58400;--mop-500:#F5B400;--mop-300:#FFD24A;--mop-200:#FFE9A8;--mop-100:#FFF6DC;\n/* --- Signal Red --- */\n--red-700:#9B211A;--red-500:#D93025;--red-200:#F6C6C2;--red-100:#FDECEA;\n/* --- Blue: links, focus, info --- */\n--blue-700:#1A4E8A;--blue-500:#2F6FBF;--blue-200:#C6DCF4;--blue-100:#EDF3FB;\n/* --- Semantic aliases: prefer these in components --- */\n--surface-page:var(--paper-100);--surface-card:var(--paper-000);--surface-sunken:var(--paper-200);--surface-inverse:var(--ink-900);--surface-accent:var(--mop-500);\n--text-body:var(--ink-900);--text-muted:var(--ink-600);--text-faint:var(--ink-500);--text-inverse:var(--paper-000);--text-on-accent:var(--ink-900);--text-link:var(--blue-700);\n--border-hairline:var(--ink-100);--border-default:var(--ink-200);--border-strong:var(--ink-400);--border-accent:var(--mop-500);\n--flag-warn:var(--mop-500);--flag-warn-wash:var(--mop-100);--flag-danger:var(--red-500);--flag-danger-wash:var(--red-100);--flag-clean:var(--blue-500);\n--focus-ring:var(--blue-500);--focus-ring-halo:var(--blue-200);\n--fold-crease:var(--ink-200);--fold-face:var(--paper-200);--fold-shade:rgba(22,24,26,.08);\n}\n:root,:host{\n--text-3xs:10px;--text-2xs:11px;--text-xs:12px;--text-sm:13px;--text-md:15px;--text-lg:18px;--text-xl:22px;--text-2xl:28px;--text-3xl:36px;--text-4xl:46px;--text-5xl:60px;\n--leading-tight:1.1;--leading-snug:1.25;--leading-body:1.55;--leading-loose:1.7;\n--weight-regular:400;--weight-medium:500;--weight-semibold:600;--weight-bold:700;\n--tracking-tight:-0.01em;--tracking-normal:0;--tracking-wide:0.01em;--tracking-caps:0.04em;\n--type-display:var(--weight-bold) var(--text-4xl)/var(--leading-tight) var(--font-display);\n--type-title:var(--weight-semibold) var(--text-2xl)/var(--leading-snug) var(--font-display);\n--type-heading:var(--weight-semibold) var(--text-md)/var(--leading-snug) var(--font-display);\n--type-body:var(--weight-regular) var(--text-md)/var(--leading-body) var(--font-body);\n--type-body-sm:var(--weight-regular) var(--text-sm)/var(--leading-body) var(--font-body);\n--type-ui:var(--weight-medium) var(--text-sm)/1.25 var(--font-body);\n--type-label:var(--weight-medium) var(--text-xs)/1.3 var(--font-body);\n--type-mono:var(--weight-regular) var(--text-xs)/1.45 var(--font-mono);\n--type-mono-label:var(--weight-medium) var(--text-3xs)/1.2 var(--font-mono);\n}\n:root,:host{\n--space-0:0px;--space-1:2px;--space-2:4px;--space-3:6px;--space-4:8px;--space-5:12px;--space-6:16px;--space-7:20px;--space-8:24px;--space-9:32px;--space-10:40px;--space-11:56px;--space-12:72px;--space-13:96px;\n/* recurring layout measurements */\n--fold-height:44px;--popup-width:360px;--popup-pad:var(--space-6);--feed-post-width:555px;--site-measure:68ch;--hairline:1px;\n}\n:root,:host{\n--radius-xs:3px;--radius-sm:6px;--radius-md:8px;--radius-lg:12px;--radius-pill:999px;\n--border-width:1px;--border-width-thick:2px;--border-width-flag:3px;\n--shadow-hairline:0 0 0 1px var(--border-hairline);/* @kind other */\n--shadow-card:0 1px 2px rgba(22,24,26,.05);/* @kind other */\n--shadow-raised:0 2px 8px rgba(22,24,26,.08);/* @kind other */\n--shadow-pop:0 8px 24px rgba(22,24,26,.14);/* @kind other */\n--shadow-inset-crease:inset 0 1px 1px rgba(22,24,26,.05);/* @kind other */\n--shadow-flag-warn:0 0 0 3px var(--mop-500);/* @kind other */\n--shadow-flag-danger:0 0 0 3px var(--red-500);/* @kind other */\n--shadow-focus:0 0 0 2px var(--paper-000),0 0 0 4px var(--focus-ring);/* @kind other */\n--glow-accent:0 0 0 4px var(--mop-200);/* @kind other */\n--gradient-fold:linear-gradient(180deg,var(--paper-000) 0%,var(--paper-100) 46%,var(--ink-200) 50%,var(--paper-100) 54%,var(--paper-000) 100%);/* @kind other */\n--gradient-sensitivity:linear-gradient(90deg,var(--ink-200) 0%,var(--mop-300) 60%,var(--mop-500) 100%);/* @kind other */\n--texture-hatch:repeating-linear-gradient(45deg,transparent 0 8px,rgba(22,24,26,.03) 8px 9px);/* @kind other */\n}\n:root,:host{\n--dur-instant:80ms;/* @kind other */\n--dur-fast:140ms;/* @kind other */\n--dur-base:220ms;/* @kind other */\n--dur-slow:380ms;/* @kind other */\n--dur-fold:520ms;/* @kind other */\n--ease-standard:cubic-bezier(.2,0,.2,1);/* @kind other */\n--ease-out:cubic-bezier(0,.6,.3,1);/* @kind other */\n--ease-fold:cubic-bezier(.22,.9,.24,1);/* @kind other */\n--ease-snap:cubic-bezier(.3,1.4,.5,1);/* @kind other */\n--transition-ui:background-color var(--dur-fast) var(--ease-standard),color var(--dur-fast) var(--ease-standard),box-shadow var(--dur-fast) var(--ease-standard),transform var(--dur-instant) var(--ease-standard);/* @kind other */\n}\n@media (prefers-reduced-motion:reduce){:root{--dur-base:0ms;/* @kind other */--dur-slow:0ms;/* @kind other */--dur-fold:0ms;/* @kind other */}}\n";
	//#endregion
	//#region src/shared/verdict.ts
	/**
	* The words a person sees for a decision, in one place so the menu and the Details panel always agree.
	* Consumer language: "Possibly" and "Likely" (the colours are yellow and red, but the words describe how sure we are).
	*/
	function verdictLabel(d, own) {
		if (own) return d.ownLevel === "red" ? {
			text: "Likely slop",
			tone: "red"
		} : d.ownLevel === "yellow" ? {
			text: "Possibly slop",
			tone: "yellow"
		} : {
			text: "Reads clean",
			tone: "green"
		};
		if (d.level === "red") return {
			text: "Likely slop",
			tone: "red"
		};
		if (d.level === "yellow") return {
			text: "Possibly slop",
			tone: "yellow"
		};
		if (d.explain?.lowConfidence) return {
			text: "Not sure",
			tone: "grey"
		};
		return {
			text: "Looks fine",
			tone: "grey"
		};
	}
	//#endregion
	//#region src/content/labels.ts
	var TELL_LABELS = {
		contrastFraming: "“not X, it’s Y” framing",
		emptyEvaluation: "generic evaluative language",
		tradeoffFreePromises: "no-tradeoff promises",
		formalHedging: "stock transitions and hedges",
		hypeMarketing: "hype vocabulary",
		manneredProse: "flourish over plain statements",
		formulaicHook: "scroll-stopper formula",
		manufacturedNarrative: "too-tidy story",
		engagementBait: "engagement bait"
	};
	/** Short names for the spider chart, in the order the axes are drawn (related tells sit next to each other). */
	var TELL_AXES = [
		{
			id: "formulaicHook",
			label: "Scroll-stopper"
		},
		{
			id: "engagementBait",
			label: "Engagement bait"
		},
		{
			id: "hypeMarketing",
			label: "Hype words"
		},
		{
			id: "emptyEvaluation",
			label: "Empty praise"
		},
		{
			id: "tradeoffFreePromises",
			label: "No-catch promises"
		},
		{
			id: "contrastFraming",
			label: "“Not X, but Y”"
		},
		{
			id: "manneredProse",
			label: "Flowery prose"
		},
		{
			id: "formalHedging",
			label: "Stiff phrasing"
		},
		{
			id: "manufacturedNarrative",
			label: "Too-tidy story"
		}
	];
	//#endregion
	//#region src/content/inspectorFormat.ts
	var NAMES = {
		...TELL_LABELS,
		humanVoice: "personal, human voice",
		usefulness: "useful to a reader"
	};
	var nameOf = (id) => NAMES[id] ?? id;
	var f2 = (n) => n.toFixed(2);
	var pct = (n) => `${Math.round(n * 100)}%`;
	var TONE_COLOR = {
		green: PALETTE.blue500,
		yellow: PALETTE.mop900,
		red: PALETTE.red500,
		grey: PALETTE.ink600
	};
	function bar(value, color) {
		return h("div", { class: "bar" }, h("i", { style: `width:${Math.round(value * 100)}%;background:${color}` }));
	}
	var tellLabel = (id) => TELL_AXES.find((a) => a.id === id)?.label ?? nameOf(id);
	//#endregion
	//#region src/content/inspectorDeveloper.ts
	/** Tell bars turn amber and red at these values. */
	var AMBER_TELL = .33;
	var RED_TELL = .66;
	/** The colour of a tell's bar: quiet, amber or red by how strong it is. */
	var tellColor = (value) => value >= RED_TELL ? PALETTE.red500 : value >= AMBER_TELL ? PALETTE.mop500 : PALETTE.ink300;
	/** Numbers for tuning: only in developer builds (the popup's Debug switch). Never shows weights. */
	function developerDetails(d, e) {
		const eng = e.engagement;
		const shieldLine = !e.shieldOn ? `${pct(d.shield)} off from usefulness alone (${f2(e.usefulness)}); your own posts don't count reader response` : `${pct(d.shield)} off (useful ${f2(e.usefulness)}, reader response ${f2(eng.norm)}${e.source === "server" ? "; worked out on the server" : ""})`;
		const row = (label, ...cells) => h("tr", {}, h("td", {}, label), h("td", {}, ...cells));
		return [
			h("h4", {}, "Developer details"),
			h("table", { class: "math" }, row("AI-drafted?", h("b", {}, f2(e.aiLikelihood)), ` → score ×${f2(e.aiDampen)}`), row("Signs standing out", h("b", {}, String(e.breakouts)), e.breakouts < 2 ? " (fewer than two: the slop score is cut)" : " (enough to count in full)"), row("Tell slop", h("b", {}, f2(d.slop)), e.source === "server" ? ` = tell mean ${f2(e.mean)}, less the human-voice offset (worked out on the server)` : ` = mean ${f2(e.mean)} × ${e.gain} − ${e.humanOffset} × voice ${f2(e.humanVoice)}`), row("Shield", shieldLine, h("br"), h("span", { class: "dim" }, `${eng.reactions} reactions · ${eng.comments} comments · ${eng.reposts} reposts`)), row("Score", h("b", {}, f2(d.score)), ` = slop × (1 − shield) × ${f2(e.aiDampen)} · ${e.sensitivity}: possibly ≥ ${f2(e.yellowAt)}, likely ≥ ${f2(e.threshold)}`), row("Confidence", h("b", {}, f2(e.meanConfidence)), " avg ", h("span", { class: e.lowConfidence ? "no" : "dim" }, e.lowConfidence ? `(below ${f2(e.minMeanConfidence)}: not trusted)` : "(fine)"))),
			h("div", { class: "rows" }, ...e.tells.flatMap((t) => [
				h("span", {
					class: "n",
					title: t.id
				}, nameOf(t.id)),
				bar(t.value, tellColor(t.value)),
				h("span", { class: "num" }, f2(t.value))
			]))
		];
	}
	var RADAR = {
		width: 340,
		height: 250,
		centerY: 124,
		radius: 74,
		rings: [
			1 / 3,
			2 / 3,
			1
		],
		minPoint: .03
	};
	var SVG_NS = "http://www.w3.org/2000/svg";
	function svgEl(tag, attrs, text) {
		const e = document.createElementNS(SVG_NS, tag);
		for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
		if (text !== void 0) e.textContent = text;
		return e;
	}
	/**
	* A spider chart of Jev's score for each tell: the further a point sits from the centre, the stronger that sign of AI
	* writing. Built with DOM APIs (LinkedIn enforces Trusted Types, so no innerHTML). Exported for tests.
	*/
	function radarChart(axes, color) {
		const { width: W, height: H, centerY: cy, radius: R, rings, minPoint } = RADAR;
		const cx = W / 2;
		const n = axes.length;
		const svg = svgEl("svg", {
			class: "radar",
			viewBox: `0 0 ${W} ${H}`,
			role: "img",
			"aria-label": `Tell strengths: ${axes.map((a) => `${a.label} ${Math.round(a.value * 100)}%`).join(", ")}`
		});
		const angle = (i) => -Math.PI / 2 + i * 2 * Math.PI / n;
		const at = (i, r) => ({
			x: cx + Math.cos(angle(i)) * r,
			y: cy + Math.sin(angle(i)) * r
		});
		const points = (radiusOf) => axes.map((_, i) => `${at(i, radiusOf(i)).x.toFixed(1)},${at(i, radiusOf(i)).y.toFixed(1)}`).join(" ");
		const reach = (a) => R * Math.max(minPoint, Math.min(1, a.value));
		for (const ring of rings) svg.append(svgEl("polygon", {
			points: points(() => R * ring),
			fill: "none",
			stroke: PALETTE.ink200,
			"stroke-width": 1
		}));
		axes.forEach((_, i) => svg.append(svgEl("line", {
			x1: cx,
			y1: cy,
			x2: at(i, R).x,
			y2: at(i, R).y,
			stroke: PALETTE.ink200,
			"stroke-width": 1
		})));
		svg.append(svgEl("polygon", {
			points: points((i) => reach(axes[i])),
			fill: color,
			"fill-opacity": .22,
			stroke: color,
			"stroke-width": 2,
			"stroke-linejoin": "round"
		}));
		axes.forEach((a, i) => {
			const tip = at(i, reach(a));
			svg.append(svgEl("circle", {
				cx: tip.x,
				cy: tip.y,
				r: 2.6,
				fill: color
			}));
			const cos = Math.cos(angle(i));
			const sin = Math.sin(angle(i));
			const label = at(i, R + 9);
			svg.append(svgEl("text", {
				x: label.x,
				y: label.y + (sin > .5 ? 9 : sin < -.5 ? -2 : 3.5),
				"text-anchor": cos > .3 ? "start" : cos < -.3 ? "end" : "middle",
				class: a.value >= .5 ? "hot" : ""
			}, a.label));
		});
		return svg;
	}
	//#endregion
	//#region src/shared/display.ts
	/**
	* The 0-100 number people see. The raw score is small (a post flagged as likely slop at Moderate scores about 0.22, which
	* reads like "78% fine"), so it is stretched, for display only, so the thresholds sit at readable numbers: "possibly slop"
	* starts at 40 and the Moderate "likely slop" line is 70 (both set by the manifest). Nothing is decided from this number:
	* verdicts, hiding and outlines all come from the raw score and the sensitivity's threshold, so changing sensitivity moves
	* where the cutoff falls and never the number a post shows.
	*/
	function displayScore(raw) {
		const v = live.values;
		const moderate = live.thresholds?.moderate ?? DEFAULT_PARAMS.thresholds.moderate;
		const stops = v.displayPossibly < v.displayLikely && v.displayLikely < 100 && v.yellowFraction < 1 && v.displayFullMultiple > 1 ? [
			[0, 0],
			[v.yellowFraction * moderate, v.displayPossibly],
			[moderate, v.displayLikely],
			[v.displayFullMultiple * moderate, 100]
		] : [
			[0, 0],
			[.6 * moderate, 40],
			[moderate, 70],
			[2 * moderate, 100]
		];
		const x = Math.min(Math.max(raw, 0), stops[3][0]);
		for (let i = 1; i < stops.length; i++) {
			const [x0, y0] = stops[i - 1];
			const [x1, y1] = stops[i];
			if (x <= x1) return y0 + (x - x0) / (x1 - x0) * (y1 - y0);
		}
		return 100;
	}
	function displayZones(explain) {
		if (!explain) return {
			possibly: live.values.displayPossibly,
			likely: live.values.displayLikely
		};
		return {
			possibly: Math.min(100, displayScore(explain.yellowAt)),
			likely: Math.min(100, displayScore(explain.threshold))
		};
	}
	//#endregion
	//#region src/shared/vote.ts
	/** A vote drives the same three colours as your own-post scores: no = blue, maybe = yellow, probably = red. */
	var voteLevel = (v) => v === "no" ? "green" : v === "maybe" ? "yellow" : "red";
	var VOTE_NAME = {
		no: "No",
		maybe: "Maybe",
		probably: "Probably"
	};
	var VOTE_HINT = {
		no: "not slop",
		maybe: "borderline",
		probably: "slop"
	};
	var VOTE_COLOR = {
		no: PALETTE.blue500,
		maybe: PALETTE.mop500,
		probably: PALETTE.red500
	};
	/** In Hide mode only "probably" hides a post; "no" and "maybe" always leave it visible, overriding the score. */
	var voteHides = (v) => v === "probably";
	//#endregion
	//#region src/content/inspectorSections.ts
	/** A tell at or above this is a "strong sign". Lower for a post that was flagged anyway. */
	var MAX_NAMED_SIGNS = 3;
	/** A full bar, as a percentage. */
	var FULL_BAR_PCT = 100;
	/** The plain verdict and the one sentence that says why. */
	function verdictHeader(data, e, verdict) {
		return [
			data.draft ? h("div", { class: "banner" }, h("b", {}, "Draft. "), "Not posted yet, so it's scored on the writing alone, with no reader response.", typeof data.draft === "object" ? ` This used one check (${data.draft.used} of ${data.draft.limit} today).` : "") : null,
			data.vote ? h("div", { class: "banner" }, "You voted ", h("b", { style: `color:${VOTE_COLOR[data.vote]}` }, VOTE_NAME[data.vote]), " on this post. Your vote overrides the score for what is shown; use the mop icon to change it.") : null,
			h("div", { class: "head" }, h("span", {
				class: "pill",
				style: `background:${TONE_COLOR[verdict.tone]}`
			}, verdict.text), h("p", { class: "outcome" }, e.outcome))
		];
	}
	/**
	* Looks fine / Possibly / Likely, with the post's place on it. The three zones are the same in both modes; in Hide mode a
	* line marks where posts get hidden. If the post sits past a line but wasn't flagged (it reads as person-written, or Jev
	* wasn't sure), the bar is dimmed and says so, so the marker isn't read as a verdict.
	*/
	function scoreZones(data, e, score) {
		const zone = displayZones(e);
		const possibly = `${zone.possibly}%`;
		const likely = `${zone.likely}%`;
		const pos = (raw) => `${Math.min(FULL_BAR_PCT, displayScore(raw))}%`;
		const hides = data.mode === "hide" && !data.own;
		const blocked = data.decision.level === "none" && score >= e.yellowAt;
		return [
			h("div", { class: blocked ? "zones blocked" : "zones" }, h("i", { style: `width:${possibly};background:${PALETTE.blue200}` }), h("i", { style: `width:calc(${likely} - ${possibly});background:${PALETTE.mop200}` }), h("i", { style: `flex:1;background:${PALETTE.red200}` }), ...hides ? [h("div", {
				class: "cut",
				style: `left:${likely}`,
				title: "Posts past this line are hidden"
			})] : [], h("div", {
				class: "dot",
				style: `left:${pos(score)}`
			})),
			h("div", { class: "zlabels" }, h("span", { style: `width:${possibly}` }, "Looks fine"), h("span", { style: `width:calc(${likely} - ${possibly})` }, "Possibly"), h("span", { style: "flex:1" }, hides ? "Likely (hidden)" : "Likely")),
			...blocked ? [h("p", { class: "note" }, "The score is past a line, but this post isn't flagged: see the note above.")] : []
		];
	}
	/** "Strongest signs: …". A flagged post always names what pushed it there; an unflagged one only mentions strong ones. */
	function strongestSigns(data, e) {
		const flagged = data.decision.level !== "none" || data.own;
		let named = e.tells.filter((t) => t.value >= (flagged ? live.values.flaggedSign : live.values.strongSign)).slice(0, MAX_NAMED_SIGNS).map((t) => tellLabel(t.id));
		if (flagged && !named.length) named = e.tells.slice(0, 2).map((t) => tellLabel(t.id));
		return named.length ? h("p", { class: "signals" }, "Strongest signs: ", h("b", {}, named.join(", "))) : h("p", { class: "signals" }, "No strong signs of AI writing.");
	}
	var personBar = (label, val) => [
		h("span", { class: "n" }, label),
		bar(val, PALETTE.blue500),
		h("span", { class: "num" }, pct(val))
	];
	//#endregion
	//#region src/content/inspectorPanel.ts
	/** The whole Details panel for one post. */
	function buildPanel(data) {
		const d = data.decision;
		const e = d.explain;
		const verdict = verdictLabel(d, data.own);
		const axes = TELL_AXES.map((a) => ({
			label: a.label,
			value: e.tells.find((t) => t.id === a.id)?.value ?? 0
		}));
		return h("div", {
			class: "panel",
			role: "tooltip",
			"aria-label": "Slop Mop breakdown"
		}, ...verdictHeader(data, e, verdict), ...scoreZones(data, e, d.score), strongestSigns(data, e), h("h4", { class: "sloppr" }, h("span", { class: "kicker" }, "The Slopprint"), "What Jev noticed"), radarChart(axes, TONE_COLOR[verdict.tone]), h("p", { class: "cap" }, "Further from the centre = a stronger sign of AI writing"), h("div", { class: "rows" }, ...personBar("Sounds like a person", e.humanVoice), ...personBar("Useful to readers", e.usefulness), ...personBar("Reader response", e.engagement.norm)), ...data.advanced ? developerDetails(d, e) : [], h("p", { class: "note" }, "Vote with the mop icon beside the post’s “…” menu."));
	}
	//#endregion
	//#region src/content/styles/inspector.css?inline
	var inspector_default = ":host{all:initial}\n*{box-sizing:border-box}\n.panel.notice{width:260px;padding:var(--space-5) var(--space-6)}\n.notice h4{margin:0 0 var(--space-2)}\n.panel{pointer-events:none;position:fixed;z-index:2147483000;width:340px;max-width:calc(100vw - 16px);max-height:min(88vh,680px);overflow:hidden;background:var(--surface-card);color:var(--text-body);border:var(--border-width) solid var(--border-hairline);border-radius:var(--radius-md);box-shadow:var(--shadow-pop);font:var(--type-body-sm);padding:var(--space-6)}\nh4{margin:var(--space-6) 0 var(--space-2);font:var(--type-label);color:var(--text-muted)}\nh4.sloppr{display:grid;gap:var(--space-1);color:var(--text-body)}\n.kicker{font:var(--type-mono-label);letter-spacing:var(--tracking-caps);text-transform:uppercase;color:var(--text-faint)}\n.head{display:flex;gap:var(--space-5);align-items:flex-start}\n.pill{flex:none;padding:2px var(--space-4);border-radius:var(--radius-xs);font:var(--type-label);font-weight:var(--weight-semibold);color:var(--paper-000);white-space:nowrap}\n.outcome{margin:0;font:var(--type-body-sm)}\n.zones{display:flex;height:8px;border-radius:var(--radius-pill);overflow:hidden;margin:var(--space-7) 0 var(--space-2);position:relative}\n.zones i{display:block;height:100%}\n.zones.blocked{opacity:.5}\n.cut{position:absolute;top:-3px;bottom:-3px;width:2px;margin-left:-1px;background:var(--ink-900)}\n.zlabels{display:flex;font:var(--type-mono-label);color:var(--text-faint)}\n.zlabels span{text-align:center;overflow:visible;white-space:nowrap}\n.dot{position:absolute;top:-4px;width:16px;height:16px;margin-left:-8px;border-radius:50%;background:var(--ink-900);border:2px solid var(--paper-000);box-shadow:var(--shadow-raised)}\n.signals{margin:var(--space-5) 0 0;font:var(--type-body-sm)}\n.signals b{font-weight:var(--weight-semibold)}\nsvg.radar{display:block;width:100%;height:auto;margin:var(--space-1) 0 0}\nsvg.radar text{font:var(--type-label);font-size:10px;fill:var(--text-muted)}\nsvg.radar text.hot{fill:var(--text-body);font-weight:var(--weight-bold)}\n.cap{margin:0;color:var(--text-faint);font:var(--type-label);text-align:center}\n.rows{display:grid;grid-template-columns:130px 1fr 34px;gap:var(--space-3) var(--space-4);align-items:center;margin-top:var(--space-2)}\n.rows .n{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.bar{height:6px;border-radius:var(--radius-pill);background:var(--paper-200);position:relative;overflow:hidden}.bar i{position:absolute;inset:0 auto 0 0;border-radius:var(--radius-pill)}\n.num{text-align:right;font:var(--type-mono);color:var(--text-faint)}\n.math{width:100%;border-collapse:collapse;font:var(--type-mono)}\n.math td{padding:var(--space-1) 0;vertical-align:top}.math td:first-child{color:var(--text-faint);padding-right:var(--space-4);width:34%}\n.ok{color:var(--blue-700);font-weight:var(--weight-semibold)}.no{color:var(--red-500);font-weight:var(--weight-semibold)}.dim{color:var(--text-faint)}\n.banner{margin:0 0 var(--space-5);padding:var(--space-3) var(--space-4);border-radius:var(--radius-sm);background:var(--surface-sunken);font:var(--type-label)}\n.banner b{font-weight:var(--weight-bold)}\n.note{color:var(--text-faint);font:var(--type-label);margin:var(--space-5) 0 0}\n";
	//#endregion
	//#region src/content/inspector.ts
	var host$1 = null;
	var root$1 = null;
	var panel = null;
	var hideTimer = 0;
	var showTimer = 0;
	function ensureHost$1() {
		if (host$1?.isConnected && root$1) return root$1;
		promoted = false;
		host$1 = document.createElement("div");
		host$1.setAttribute("data-slopmop-inspector", "");
		root$1 = host$1.attachShadow({ mode: "open" });
		root$1.append(style(tokens_default + inspector_default));
		document.body.appendChild(host$1);
		return root$1;
	}
	function close() {
		clearTimeout(showTimer);
		panel?.remove();
		panel = null;
	}
	var scheduleClose = () => {
		clearTimeout(showTimer);
		clearTimeout(hideTimer);
		hideTimer = window.setTimeout(close, 60);
	};
	var cancelClose = () => clearTimeout(hideTimer);
	var current = null;
	/** True while the panel host is shown as a popover (in the top layer). */
	var promoted = false;
	function render$1(data) {
		if (!current) return;
		const r = ensureHost$1();
		panel?.remove();
		panel = buildPanel(data);
		r.append(panel);
		place$1(panel);
	}
	/** Puts a freshly built panel where it belongs, above a modal if the anchor is inside one. */
	function place$1(el) {
		if (!current) return;
		panel = el;
		promote(current.anchor, current.modal);
		position(current.anchor);
	}
	/**
	* An open modal <dialog> (LinkedIn's post composer) sits in the browser's top layer, above anything else on the page whatever its
	* z-index. Panels for something inside one are promoted into the top layer too (a manual popover, styled to be invisible itself),
	* and returned to the ordinary page when they close.
	*/
	function promote(anchor, modal) {
		const el = host$1;
		if (!el) return;
		if ((modal?.isConnected || openModalAround(anchor)) && typeof el.showPopover === "function") {
			if (!promoted) {
				el.setAttribute("popover", "manual");
				el.style.cssText = "position:fixed;inset:0;width:0;height:0;margin:0;padding:0;border:0;background:none;overflow:visible;pointer-events:none";
				el.showPopover();
				promoted = true;
			}
		} else demote();
	}
	/** The open modal dialog around `node`, looking out through shadow roots (a button inside a shadow tree can't find it with closest()). */
	function openModalAround(node) {
		for (let n = node; n; n = n.parentNode ?? n.host ?? null) if (n instanceof Element && n.matches("dialog[open]")) return true;
		return false;
	}
	function demote() {
		const el = host$1;
		if (!el || !promoted) return;
		promoted = false;
		try {
			el.hidePopover?.();
		} catch {}
		el.removeAttribute("popover");
		el.style.cssText = "";
	}
	function position(anchor) {
		if (!panel) return;
		const a = anchor.getBoundingClientRect();
		const pw = panel.offsetWidth;
		const ph = panel.offsetHeight;
		const vw = window.innerWidth;
		const vh = window.innerHeight;
		if (current?.avoid) {
			const av = current.avoid;
			const left = av.right + 12 + pw <= vw - 8 ? av.right + 12 : av.left - 12 - pw >= 8 ? av.left - 12 - pw : Math.max(8, Math.min(av.right - pw - 16, vw - pw - 8));
			panel.style.left = `${left}px`;
			panel.style.top = `${Math.min(Math.max(8, av.top), Math.max(8, vh - ph - 8))}px`;
			return;
		}
		if (current?.side) {
			const left = a.left - pw - 10 >= 8 ? a.left - pw - 10 : a.right + 10 + pw <= vw - 8 ? a.right + 10 : Math.max(8, vw - pw - 8);
			panel.style.left = `${left}px`;
			panel.style.top = `${Math.min(Math.max(8, a.top), Math.max(8, vh - ph - 8))}px`;
			return;
		}
		let top = a.bottom + 6;
		if (top + ph > vh - 8) top = Math.max(8, a.top - ph - 6);
		if (top + ph > vh - 8) top = Math.max(8, vh - ph - 8);
		const left = Math.min(Math.max(8, a.left + a.width / 2 - pw / 2), vw - pw - 8);
		panel.style.top = `${top}px`;
		panel.style.left = `${left}px`;
	}
	/** Hover (or keyboard focus) on `target` opens the breakdown panel. `get` runs at open time so it reflects current settings. */
	function bindInspector(target, get) {
		const open = () => {
			cancelClose();
			clearTimeout(showTimer);
			showTimer = window.setTimeout(() => {
				const data = get();
				if (!data?.decision.explain) return;
				current = {
					anchor: target,
					get
				};
				render$1(data);
			}, 120);
		};
		target.addEventListener("mouseenter", open);
		target.addEventListener("pointerdown", closeInspector);
		target.addEventListener("focusin", open);
		target.addEventListener("mouseleave", scheduleClose);
		target.addEventListener("focusout", scheduleClose);
	}
	function closeInspector() {
		current = null;
		close();
		demote();
	}
	/** Shows the breakdown beside `anchor` (the mop menu). Used by the menu's "Details" item; hide with closeInspector(). */
	function showInspectorBeside(anchor, data) {
		if (!data.decision.explain) return;
		cancelClose();
		current = {
			anchor,
			get: () => data,
			side: true
		};
		render$1(data);
	}
	/**
	* The breakdown for a draft in the composer: beside the dialog (not over the text being written), above it in the top layer,
	* and it stays until dismissed (a click, Escape, or the dialog closing), unlike the hover tooltip.
	*/
	function showDraftInspector(anchor, dialog, data) {
		if (!data.decision.explain) return;
		cancelClose();
		current = {
			anchor,
			get: () => data,
			avoid: dialog.getBoundingClientRect(),
			modal: dialog
		};
		render$1(data);
	}
	/** A short message beside the dialog (for example "write a little more first"), in the same style and place as the breakdown. */
	function showNotice(anchor, dialog, title, body) {
		cancelClose();
		current = {
			anchor,
			get: () => null,
			avoid: dialog.getBoundingClientRect(),
			modal: dialog
		};
		const r = ensureHost$1();
		panel?.remove();
		const el = document.createElement("div");
		el.className = "panel notice";
		const h5 = document.createElement("h4");
		h5.textContent = title;
		const p = document.createElement("p");
		p.className = "outcome";
		p.textContent = body;
		el.append(h5, p);
		r.append(el);
		place$1(el);
	}
	//#endregion
	//#region src/content/selectors.ts
	/**
	* Every LinkedIn-specific selector lives here. LinkedIn changes its DOM often, so this is the one
	* file to touch when extraction breaks. Each entry lists fallbacks, tried in order.
	*
	* Verified against the live feed on 2026-09-18: classes are hashed and there are no
	* `urn:li:activity` attributes, so the current markup is found through role/componentkey/data-testid.
	* The legacy (pre-hash) selectors are kept as fallbacks.
	*/
	var SEL = {
		post: [
			"[role=\"listitem\"][componentkey^=\"update-card\"]",
			"div[data-urn^=\"urn:li:activity:\"]",
			"div[data-id^=\"urn:li:activity:\"]",
			".feed-shared-update-v2"
		],
		/** Current markup: the post id is the componentkey minus this prefix. */
		componentKeyPrefix: /^update-card(?:-focus)?/,
		urnAttrs: ["data-urn", "data-id"],
		text: [
			"[data-testid=\"expandable-text-box\"]",
			".update-components-text",
			".feed-shared-update-v2__description",
			".feed-shared-inline-show-more-text"
		],
		/** Trailing "… more" control that LinkedIn renders inside the text box. */
		moreSuffix: /[\s…]*\bmore\s*$/i,
		/** Counts are rendered as leaf text like "34 reactions", "16 comments", "5 reposts". */
		countLeaf: "span,p,button,a,div",
		promotedLeaf: "span,p,div",
		promotedText: /^\s*(promoted|sponsored)\s*$/i,
		/**
		* Ads: verified 2026-09-18 that a sponsored card carries an element (an svg on the creative link) with
		* aria-label "View Sponsored Content" and no "Promoted" text leaf, so any sponsored/promoted aria-label counts.
		*/
		adAria: /\b(sponsored|promoted)\b/i,
		/** "Open control menu for post by <Name>" names the post's author on every card. */
		authorAria: "[aria-label^=\"Open control menu for post by \"]",
		authorPrefix: "Open control menu for post by ",
		/** Your own posts also say so in their author line ("• You"), which works even when your name hasn't been learned yet. */
		youMarker: /^\s*•?\s*You\s*$/,
		actorScope: "[class*=\"actor\"]",
		/** Left-rail profile card: an avatar whose alt is the signed-in user's name, linking to their profile. */
		profileImg: "img[alt]",
		profileHref: /\/in\/[^/?#]+\/?(?:[?#].*)?$/,
		/**
		* The "Start a post" composer, a modal <dialog> verified on 2026-09-21: the editor is a role=textbox. The mop button is NOT put
		* into LinkedIn's toolbar (it reshuffles and collapses that as the draft grows, and a sibling there can land on top of another
		* icon): it floats inside the dialog, beside the footer's Post button.
		*/
		composer: {
			dialog: "dialog[open], [role=\"dialog\"]",
			editor: "[role=\"textbox\"][contenteditable=\"true\"], .ql-editor",
			/** The footer's Post button, found by its label (English); without it the mop button sits in the dialog's bottom right. */
			postLabel: /^\s*Post\s*$/i
		}
	};
	var POST_SELECTOR = SEL.post.join(",");
	function firstMatch(root, selectors) {
		for (const s of selectors) {
			const el = root.querySelector(s);
			if (el) return el;
		}
		return null;
	}
	//#endregion
	//#region src/content/styles/composer.css?inline
	var composer_default = ":host{all:initial;display:flex;align-items:center;justify-content:center;width:48px;height:48px}\nbutton{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;cursor:pointer;color:var(--ink-600);transition:var(--transition-ui)}\nbutton:hover{background:var(--paper-200);color:var(--ink-900)}\nbutton:focus-visible{box-shadow:var(--shadow-focus)}\nbutton[aria-busy=true]{cursor:progress}\n.dots{display:inline-flex;align-items:center;gap:3px}\n.dots i{display:block;width:4px;height:4px;border-radius:50%;background:var(--ink-500);animation:bounce 1s ease-in-out infinite}\n.dots i:nth-child(2){animation-delay:.15s}\n.dots i:nth-child(3){animation-delay:.3s}\n@keyframes bounce{0%,60%,100%{transform:translateY(0);opacity:.45}30%{transform:translateY(-4px);opacity:1}}\n@media (prefers-reduced-motion:reduce){.dots i{animation:none}}\n";
	//#endregion
	//#region src/content/composer.ts
	/**
	* "Check this draft": a mop button in LinkedIn's post composer that scores what you have written so far, before you post it, and
	* shows the same breakdown a posted post gets. It is a manual button (nothing is sent until you press it) and each new text
	* costs one of the day's checks like any other post; the same text again is answered from this browser and costs nothing.
	*/
	var DRAFT_MIN_CHARS = 20;
	var NO_ENGAGEMENT = {
		reactions: 0,
		comments: 0,
		reposts: 0
	};
	var mounted = /* @__PURE__ */ new WeakMap();
	var openHosts = /* @__PURE__ */ new Set();
	/** Puts the draft's breakdown away; set while it is on screen. */
	var dismissDraft = null;
	var TITLE = "Check this draft with Slop Mop (uses one of your daily checks)";
	function createButton(onPress) {
		const host = document.createElement("div");
		host.setAttribute("data-slopmop-composer", "");
		const root = host.attachShadow({ mode: "open" });
		const button = h("button", {
			type: "button",
			"aria-label": "Check this draft with Slop Mop",
			title: TITLE
		});
		button.append(mopIcon(24, "currentColor", PALETTE.paper000));
		button.addEventListener("click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			onPress();
		});
		root.append(style(tokens_default + composer_default), button);
		return {
			host,
			button,
			busy: false
		};
	}
	var editorText = (editor) => (editor.innerText ?? editor.textContent ?? "").replace(/\s+\n/g, "\n").trim();
	/** Working: the mop turns into three bouncing dots until the answer comes back. */
	function setBusy(m, busy) {
		m.busy = busy;
		m.button.setAttribute("aria-busy", String(busy));
		m.button.replaceChildren(busy ? h("span", {
			class: "dots",
			role: "img",
			"aria-label": "Checking"
		}, h("i", {}), h("i", {}), h("i", {})) : mopIcon(24, "currentColor", PALETTE.paper000));
	}
	/** Closes the breakdown on a click anywhere, on Escape, or when the composer goes away. */
	function dismissOnAnyInteraction(dialog) {
		const off = () => {
			document.removeEventListener("pointerdown", onDown, true);
			document.removeEventListener("keydown", onKey, true);
			observer.disconnect();
		};
		const close = () => {
			off();
			dismissDraft = null;
			closeInspector();
		};
		dismissDraft = close;
		const onDown = (e) => {
			if (e.target?.closest?.("[data-slopmop-composer]")) return;
			close();
		};
		const onKey = (e) => e.key === "Escape" && close();
		const observer = new MutationObserver(() => !dialog.isConnected || !dialog.open && dialog.tagName === "DIALOG" ? close() : void 0);
		document.addEventListener("pointerdown", onDown, true);
		document.addEventListener("keydown", onKey, true);
		observer.observe(document.body, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: ["open"]
		});
	}
	async function check(dialog, editor, m) {
		if (m.busy) return;
		if (dismissDraft) return dismissDraft();
		const text = editorText(editor);
		if (text.length < DRAFT_MIN_CHARS) {
			showNotice(m.button, dialog, "Write a little more first", `Slop Mop needs at least ${DRAFT_MIN_CHARS} characters to judge a draft.`);
			return dismissOnAnyInteraction(dialog);
		}
		setBusy(m, true);
		try {
			const response = await send({
				type: "judge",
				urn: `draft:${text.length}`,
				text,
				stats: surfaceStats(text),
				priority: 0,
				engagement: NO_ENGAGEMENT
			});
			if (!response) {
				const why = (await send({ type: "myDebug" }).catch(() => null))?.lastError;
				showNotice(m.button, dialog, "Couldn't check this draft", why || "The Slop Mop server didn't answer. Try again in a moment.");
				return dismissOnAnyInteraction(dialog);
			}
			const decision = decideOwn(response, state.settings.sensitivity, scoringParams());
			if (!decision.explain) {
				showNotice(m.button, dialog, "Nothing to judge yet", "Jev didn't return anything usable for this text.");
				return dismissOnAnyInteraction(dialog);
			}
			const used = response.usage;
			showDraftInspector(m.button, dialog, {
				urn: "draft",
				text,
				own: true,
				engagement: NO_ENGAGEMENT,
				response,
				decision,
				mode: state.settings.mode,
				sensitivity: state.settings.sensitivity,
				vote: null,
				advanced: state.settings.debug,
				draft: used ? {
					used: used.used,
					limit: used.limit
				} : true
			});
			dismissOnAnyInteraction(dialog);
		} finally {
			setBusy(m, false);
		}
	}
	/** The composers on the page right now: an open dialog with an editor. */
	function composers() {
		const found = [];
		for (const dialog of document.querySelectorAll(SEL.composer.dialog)) {
			const editor = dialog.querySelector(SEL.composer.editor);
			if (editor) found.push({
				dialog,
				editor
			});
		}
		return found;
	}
	var BUTTON_PX = 48;
	var GAP_PX = 8;
	var FALLBACK_FROM_RIGHT_PX = 300;
	/** The group of controls around Post is small; a parent wider than this is the whole footer, not that group. */
	var MAX_GROUP_PX = 400;
	/**
	* Floats the button inside the dialog, left of the row that holds the Post button, and follows that row as the dialog changes.
	* It is positioned, never inserted into LinkedIn's own layout, so it can't push, collapse or overlap anything there.
	*/
	function place(dialog, host) {
		const d = dialog.getBoundingClientRect();
		const post = [...dialog.querySelectorAll("button")].find((b) => SEL.composer.postLabel.test(b.textContent ?? ""));
		let left = d.width - FALLBACK_FROM_RIGHT_PX;
		let top = d.height - BUTTON_PX - 16;
		if (post) {
			const p = post.getBoundingClientRect();
			const group = post.parentElement?.getBoundingClientRect();
			left = (group && group.width >= p.width && group.width <= MAX_GROUP_PX ? Math.min(group.left, p.left) : p.left) - d.left - BUTTON_PX - GAP_PX;
			top = p.top - d.top + (p.height - BUTTON_PX) / 2;
		}
		host.style.cssText = `position:absolute;left:${Math.max(0, Math.round(left))}px;top:${Math.max(0, Math.round(top))}px;z-index:5;width:${BUTTON_PX}px;height:${BUTTON_PX}px`;
	}
	/** Puts the mop button in every open composer (once each), keeps it beside Post, and takes it out of ones that have closed. Called on every page change. */
	function syncComposer() {
		const live = active() ? composers() : [];
		for (const { dialog, editor } of live) {
			let m = mounted.get(dialog);
			if (!m?.host.isConnected || m.host.parentElement !== dialog) {
				m?.host.remove();
				m = createButton(() => void check(dialog, editor, m));
				mounted.set(dialog, m);
				openHosts.add(m.host);
				dialog.append(m.host);
			}
			place(dialog, m.host);
		}
		for (const host of [...openHosts]) {
			if (live.some(({ dialog }) => mounted.get(dialog)?.host === host)) continue;
			host.remove();
			openHosts.delete(host);
		}
	}
	/** Removes the buttons (the extension was switched off or reloaded). */
	function clearComposer() {
		for (const host of openHosts) host.remove();
		openHosts.clear();
	}
	window.addEventListener("resize", () => syncComposer());
	//#endregion
	//#region src/content/extractSignals.ts
	function getUrn(el) {
		const key = el.getAttribute("componentkey");
		if (key && SEL.componentKeyPrefix.test(key)) return `post:${key.replace(SEL.componentKeyPrefix, "")}`;
		for (const a of SEL.urnAttrs) {
			const v = el.getAttribute(a);
			if (v?.startsWith("urn:li:activity:")) return v;
		}
		return el.querySelector("[data-urn^=\"urn:li:activity:\"]")?.getAttribute("data-urn") ?? null;
	}
	/** Parses "1.2K", "3,456", "12 comments" style counts. */
	function parseCount(raw) {
		if (!raw) return 0;
		const m = raw.replace(/,/g, "").match(/(\d+(?:\.\d+)?)\s*([kKmM])?/);
		if (!m) return 0;
		const n = parseFloat(m[1]);
		return Math.round(m[2] ? n * (m[2].toLowerCase() === "k" ? 1e3 : 1e6) : n);
	}
	/** Finds a leaf element whose whole text is "<count> <word>(s)" and returns the count. */
	function countFor(el, word) {
		const re = new RegExp(`^\\s*(\\d[\\d,.]*\\s*[kKmM]?)\\s+${word}s?\\s*$`, "i");
		for (const n of el.querySelectorAll(SEL.countLeaf)) {
			if (n.childElementCount > 0) continue;
			const m = re.exec(n.textContent ?? "");
			if (m) return parseCount(m[1]);
		}
		return 0;
	}
	/** True for sponsored/promoted cards. Never analysed, sent, hidden or outlined. */
	function isAd(el) {
		for (const n of el.querySelectorAll("[aria-label]")) if (SEL.adAria.test(n.getAttribute("aria-label") ?? "")) return true;
		for (const n of el.querySelectorAll(SEL.promotedLeaf)) if (n.childElementCount === 0 && SEL.promotedText.test(n.textContent ?? "")) return true;
		return false;
	}
	/** True when the author line of the post says "• You": it is the signed-in user's own post. */
	function saysYou(el) {
		for (const scope of el.querySelectorAll(SEL.actorScope)) for (const n of scope.querySelectorAll("span")) if (n.childElementCount === 0 && SEL.youMarker.test(n.textContent ?? "") && /•/.test(scope.textContent ?? "")) return true;
		return false;
	}
	function authorOf(el) {
		const label = el.querySelector(SEL.authorAria)?.getAttribute("aria-label");
		return label ? label.slice(SEL.authorPrefix.length).trim() : null;
	}
	/**
	* The signed-in user's name, read from the left-rail profile avatar (an <img alt=name> linking to /in/...),
	* ignoring avatars inside post cards. First match in document order wins.
	*/
	function findOwnName(root = document) {
		for (const img of root.querySelectorAll(SEL.profileImg)) {
			const alt = img.alt.trim();
			if (!alt || img.closest(POST_SELECTOR)) continue;
			const href = img.closest("a")?.getAttribute("href") ?? "";
			if (SEL.profileHref.test(href)) return alt;
		}
		return null;
	}
	/** The reaction, comment and repost counts a post shows right now. */
	var readEngagement = (el) => ({
		reactions: countFor(el, "reaction"),
		comments: countFor(el, "comment"),
		reposts: countFor(el, "repost")
	});
	/**
	* `lenient` (debug only) lets short and non-English posts through as `inspectOnly`, so every post can be
	* inspected and voted on. They are never hidden or outlined: the normal thresholds still apply to everything else.
	*/
	function inspectPost(el, ownName = null, lenient = false) {
		const urn = getUrn(el);
		if (!urn) return { status: "noId" };
		if (isAd(el)) return { status: "ad" };
		const author = authorOf(el);
		const own = !!ownName && author === ownName || saysYou(el);
		const textEl = firstMatch(el, SEL.text);
		const text = (textEl?.innerText ?? textEl?.textContent ?? "").replace(SEL.moreSuffix, "").replace(/[ \t]+\n/g, "\n").trim();
		const tooShort = text.length < (own ? live.values.minOwnChars : live.values.minChars);
		const notEnglish = !tooShort && !looksEnglish(text);
		const inspectOnly = tooShort || notEnglish;
		if (inspectOnly && !(lenient && text.length >= 20)) return { status: tooShort ? "short" : "notEnglish" };
		return {
			status: "ok",
			post: {
				urn,
				text,
				own,
				inspectOnly: inspectOnly || void 0,
				engagement: readEngagement(el)
			}
		};
	}
	/** Cheap check: Jev is strongest in English, so skip posts that are mostly non-Latin or non-English function words. */
	function looksEnglish(text) {
		const letters = text.match(/\p{L}/gu) ?? [];
		if (!letters.length) return false;
		if ((text.match(/\p{Script=Latin}/gu) ?? []).length / letters.length < .9) return false;
		const hits = text.toLowerCase().match(/\b(the|and|to|of|is|in|that|it|for|you|with|on|are|this|we|i)\b/g) ?? [];
		const words = text.split(/\s+/).length;
		return hits.length / words > .12;
	}
	//#endregion
	//#region src/content/analysis.ts
	/** Asks for a verdict on a post (once, unless forced) and records the answer. */
	function analyze(t, priority, force = false) {
		if (t.pending) return t.pending;
		if (t.requested && !force) return Promise.resolve();
		if (!active() || isAd(t.el)) return Promise.resolve();
		if (t.inspectOnly && !force) return Promise.resolve();
		t.requested = true;
		t.done = false;
		t.pending = (async () => {
			t.response = await send({
				type: "judge",
				urn: t.urn,
				text: t.text,
				stats: surfaceStats(t.text),
				priority,
				nativeId: t.urn.startsWith("urn:li:") ? t.urn : void 0,
				engagement: t.engagement
			});
			t.done = true;
			await recordOutcome(t);
			hooks.render(t);
		})().finally(() => t.pending = void 0);
		return t.pending;
	}
	/**
	* Asks again for a post whose engagement has grown a step since it was checked: Jev's answer to the text is the same, but the
	* server's shield (its reader-response half) has moved. The old answer stays until the new one arrives, and stays if it can't.
	*/
	function recheck(t) {
		if (t.pending || !t.response || !active()) return Promise.resolve();
		t.pending = (async () => {
			const fresh = await send({
				type: "judge",
				urn: t.urn,
				text: t.text,
				stats: surfaceStats(t.text),
				priority: 1,
				nativeId: t.urn.startsWith("urn:li:") ? t.urn : void 0,
				engagement: t.engagement
			});
			if (!fresh) return;
			t.response = fresh;
			t.community = fresh.community ?? t.community;
			hooks.render(t);
		})().finally(() => t.pending = void 0);
		return t.pending;
	}
	/** What happens after a check: an answer is kept, a dropped post is asked for again later, a failure is explained and retried. */
	async function recordOutcome(t) {
		if (t.response) {
			t.cancelled = false;
			t.failure = null;
			t.contentId = t.response.contentId;
			t.community = t.response.community;
		} else if (t.cancelled) {
			t.cancelled = false;
			t.requested = false;
			t.done = false;
		} else {
			t.failure = ((await send({ type: "myDebug" }).catch(() => null))?.lastError ?? null) || "The Slop Mop server didn't answer.";
			scheduleRetry(t);
		}
	}
	/** A server that was briefly unreachable shouldn't leave a post unscored (no border) for the rest of the session. */
	function scheduleRetry(t) {
		const delays = live.values.postRetryDelaysMs;
		if (t.retries >= delays.length) return;
		const delay = delays[t.retries++];
		window.setTimeout(() => {
			if (!t.response && t.el.isConnected && active()) {
				t.requested = false;
				analyze(t, 0, true);
			}
		}, delay);
	}
	/** Makes sure the post has a Jev verdict (scoring it now if it was never scored), so it can be shown and voted on. */
	async function ensureVerdict(t) {
		if (t.response) return t.response;
		if (t.pending) await t.pending;
		if (!t.response) await analyze(t, 0, true);
		return t.response;
	}
	//#endregion
	//#region src/content/observers.ts
	/** Analyze posts well before they scroll into view. */
	var rootMargin = () => `${rootMarginPx()}px 0px ${rootMarginPx()}px 0px`;
	/**
	* One IntersectionObserver per scroll container. LinkedIn scrolls inside <main> (overflow-y: scroll),
	* and a root-less observer can't see past that clip, so its rootMargin lookahead would do nothing.
	*/
	var observers = /* @__PURE__ */ new Map();
	/** Stops watching every post. */
	function stopObserving() {
		for (const io of observers.values()) io.disconnect();
		observers.clear();
	}
	function scrollParent(el) {
		for (let p = el.parentElement; p && p !== document.documentElement; p = p.parentElement) {
			const overflow = getComputedStyle(p).overflowY;
			if ((overflow === "auto" || overflow === "scroll") && p.scrollHeight > p.clientHeight) return p;
		}
		return null;
	}
	function observerFor(el) {
		const root = scrollParent(el);
		let io = observers.get(root);
		if (!io) {
			io = new IntersectionObserver((entries) => {
				for (const e of entries) {
					if (!e.isIntersecting) continue;
					const t = byEl.get(e.target);
					if (t) analyze(t, Math.abs(e.boundingClientRect.top - (root?.getBoundingClientRect().top ?? 0)));
				}
			}, {
				root,
				rootMargin: rootMargin()
			});
			observers.set(root, io);
		}
		return io;
	}
	//#endregion
	//#region src/content/view.ts
	/** Hidden when it should be hidden and hasn't been unfolded; ringed when it should be hidden and has been. */
	var foldOrRing = (hide, restored) => ({
		fold: hide && !restored,
		refold: hide && restored
	});
	/**
	* Your own posts: always a coloured border (by your vote, else by score), never hidden.
	* Someone else's post you voted on: the vote replaces the score (Highlight: coloured border; Hide: "probably" hides it).
	* A post nobody voted on: hidden, outlined or left alone by its score and the mode.
	* Null means "leave what is there alone".
	*/
	function desiredView(f) {
		const none = {
			fold: false,
			refold: false
		};
		if (f.own) {
			if (!f.scored && !f.vote) return {
				...none,
				outline: null
			};
			if (f.vote) return {
				...none,
				outline: {
					key: `vote:${f.vote}`,
					kind: "vote",
					vote: f.vote
				}
			};
			return {
				...none,
				outline: {
					key: `own:${f.ownLevel}`,
					kind: "own",
					level: f.ownLevel
				}
			};
		}
		if (f.vote) return {
			...foldOrRing(f.mode === "hide" && voteHides(f.vote), f.restored),
			outline: f.mode === "highlight" ? {
				key: `vote:${f.vote}`,
				kind: "vote",
				vote: f.vote
			} : null
		};
		if (f.inspectOnly) return null;
		const d = f.decision;
		return {
			...foldOrRing(d.hide, f.restored),
			outline: d.level !== "none" && f.mode === "highlight" ? {
				key: `score:${d.level}`,
				kind: "score",
				decision: d
			} : null
		};
	}
	//#endregion
	//#region src/shared/labelNormalize.ts
	/** Earlier builds stored "slop" / "not-slop"; map them onto the three-way vote. */
	function normalizeVote(v) {
		if (v === "no" || v === "maybe" || v === "probably") return v;
		if (v === "slop") return "probably";
		if (v === "not-slop") return "no";
		return null;
	}
	function normalizeRecord(r) {
		const rec = r;
		const label = normalizeVote(rec?.label);
		if (!rec || !label || typeof rec.urn !== "string" || !rec.verdict) return null;
		return {
			...rec,
			label
		};
	}
	//#endregion
	//#region src/shared/labels.ts
	async function allLabels() {
		const all = await chrome.storage.local.get(null);
		return Object.entries(all).filter(([k]) => k.startsWith("label:")).map(([, v]) => normalizeRecord(v)).filter((r) => r !== null).sort((a, b) => a.at - b.at);
	}
	//#endregion
	//#region src/content/votes.ts
	/** Your votes, keyed by post id. Loaded once, then kept current from storage so other tabs' votes show up too. */
	var votes = /* @__PURE__ */ new Map();
	var voteOf = (urn) => votes.get(urn)?.label ?? null;
	var setVote = (rec) => void votes.set(rec.urn, rec);
	var dropVote = (urn) => void votes.delete(urn);
	async function loadVotes() {
		for (const r of await allLabels()) votes.set(r.urn, r);
	}
	function watchVotes(onChange) {
		chrome.storage.onChanged.addListener((changes, area) => {
			if (area !== "local") return;
			for (const [key, ch] of Object.entries(changes)) {
				if (!key.startsWith("label:")) continue;
				const urn = key.slice(6);
				const rec = normalizeRecord(ch.newValue);
				if (rec) votes.set(urn, rec);
				else votes.delete(urn);
				onChange(urn);
			}
		});
	}
	//#endregion
	//#region src/content/decision.ts
	/** Fresh decision for a post under the current settings. */
	function decisionFor(t) {
		const { settings } = state;
		return t.own ? decideOwn(t.response, settings.sensitivity, scoringParams()) : decide(t.response, t.engagement, settings.mode, settings.sensitivity, { params: scoringParams() });
	}
	/** Getter handed to the fold strip's hover tooltip and the menu's Details item. Null until Jev has answered. */
	function inspectFor(t) {
		return () => {
			if (!t.response) return null;
			const { settings } = state;
			return {
				urn: t.urn,
				text: t.text,
				own: t.own,
				engagement: t.engagement,
				response: t.response,
				decision: decisionFor(t),
				mode: settings.mode,
				sensitivity: settings.sensitivity,
				vote: voteOf(t.urn),
				advanced: settings.debug
			};
		};
	}
	/** What the menu shows for this post right now. */
	function menuState(t) {
		const base = {
			current: voteOf(t.urn),
			canRefold: !!t.refold,
			inspect: inspectFor(t)(),
			community: t.community ?? null
		};
		if (!t.response) {
			const scoring = !!t.pending || !t.done;
			return {
				...base,
				score: null,
				verdict: "",
				tone: "grey",
				zones: displayZones(null),
				scoring,
				problem: scoring ? null : `Couldn't score this post. ${t.failure ?? ""}`.trim()
			};
		}
		const d = decisionFor(t);
		const { text: verdict, tone } = verdictLabel(d, t.own);
		return {
			...base,
			score: Math.round(displayScore(d.score)),
			verdict,
			tone,
			zones: displayZones(d.explain),
			scoring: false,
			problem: null
		};
	}
	//#endregion
	//#region src/shared/dial.ts
	/** Half-moon dial: arc = 0..personal daily record, dot = today. Red dot at the far right = new record. */
	function dialEl(d, width = 64) {
		const cx = 32, cy = 32, r = 26;
		const a = Math.PI * (1 - Math.min(1, Math.max(0, d.dial)));
		const dx = (cx + r * Math.cos(a)).toFixed(2);
		const dy = (cy - r * Math.sin(a)).toFixed(2);
		const hot = d.isNewRecord || d.dial >= 1;
		return s("svg", {
			viewBox: "0 0 64 38",
			width,
			height: width * 38 / 64,
			role: "img",
			"aria-label": "Today versus your daily record"
		}, s("path", {
			d: "M6 32 A26 26 0 0 1 58 32",
			fill: "none",
			stroke: PALETTE.ink200,
			"stroke-width": 5,
			"stroke-linecap": "round"
		}), s("path", {
			d: `M6 32 A26 26 0 0 1 ${dx} ${dy}`,
			fill: "none",
			stroke: hot ? PALETTE.red500 : PALETTE.ink600,
			"stroke-width": 5,
			"stroke-linecap": "round",
			opacity: d.dial > 0 ? 1 : 0
		}), s("circle", {
			cx: dx,
			cy: dy,
			r: 4.2,
			fill: hot ? PALETTE.red500 : PALETTE.ink900,
			stroke: PALETTE.paper000,
			"stroke-width": 1.5
		}));
	}
	//#endregion
	//#region src/content/styles/page.css?inline
	var page_default = "/* Rules injected into the LinkedIn page itself (not the shadow DOM). The hidden attribute name must match HIDDEN_ATTR in fold.ts. */\n[data-slopmop-hidden]{display:none!important}\n[data-slopmop-measure]{display:block!important;position:absolute!important;visibility:hidden!important;pointer-events:none!important}\n[data-slopmop-reveal]{animation:slopmop-fade .38s ease both}\n@keyframes slopmop-fade{from{opacity:0}to{opacity:1}}\n";
	//#endregion
	//#region src/content/styles/fold.css?inline
	var fold_default = ":host{all:initial;display:block;margin:0 0 var(--space-4);container-type:inline-size}\n*{box-sizing:border-box}\n.wrap{position:relative;height:var(--fold-h);perspective:900px;transition:height var(--dur-fold) var(--ease-fold);cursor:pointer;font:var(--type-ui);color:var(--text-body)}\n.wrap:focus-visible{outline:none;box-shadow:var(--shadow-focus);border-radius:var(--radius-sm)}\n.half{position:absolute;left:0;right:0;height:50%;background:linear-gradient(var(--paper-000),var(--paper-100));border:var(--border-width) solid var(--border-hairline);box-shadow:var(--shadow-card);transition:transform var(--dur-fold) var(--ease-fold),background var(--dur-fold)}\n.top{top:0;transform-origin:50% 100%;transform:rotateX(38deg);border-radius:var(--radius-sm) var(--radius-sm) 0 0;border-bottom:0}\n.bot{bottom:0;transform-origin:50% 0;transform:rotateX(-38deg);border-radius:0 0 var(--radius-sm) var(--radius-sm);border-top:0;background:linear-gradient(var(--paper-100),var(--paper-000))}\n.crease{position:absolute;left:0;right:0;top:50%;height:1px;background:var(--fold-crease);transition:opacity var(--dur-base)}\n.content{position:absolute;inset:0;display:flex;align-items:center;gap:var(--space-5);padding:0 var(--space-5) 0 var(--space-6);overflow:hidden;transition:opacity var(--dur-base)}\n.brand{display:flex;align-items:center;gap:var(--space-4);white-space:nowrap;min-width:0;overflow:hidden}\n.brand svg{flex:none}\n.label{overflow:hidden;text-overflow:ellipsis}\n.stats{margin-left:auto;display:flex;align-items:center;gap:var(--space-5);flex:none}\n.stat{display:flex;align-items:baseline;gap:var(--space-2);white-space:nowrap}\n.stat b{font:var(--type-mono);font-weight:var(--weight-medium);color:var(--text-body)}\n.stat span{font:var(--type-mono-label);color:var(--text-faint)}\n.dial{display:flex;align-items:center}\n.show{flex:none;display:inline-flex;align-items:center;height:26px;padding:0 var(--space-5);border:var(--border-width) solid var(--border-default);border-radius:var(--radius-sm);background:var(--paper-000);font:var(--type-label);transition:var(--transition-ui)}\n.wrap:hover .show{background:var(--paper-100)}\n.wrap.open .half{transform:rotateX(0);background:var(--paper-000)}\n.wrap.open .content,.wrap.open .crease{opacity:0}\n@container (max-width:560px){.stat:nth-child(n+3),.dial{display:none}}\n@container (max-width:380px){.stats{display:none}}\n@media (prefers-reduced-motion:reduce){.wrap,.half{transition:none!important}}\n";
	//#endregion
	//#region src/content/fold.ts
	var PAGE_CSS_ID = "slopmop-page-css";
	var HIDDEN_ATTR = "data-slopmop-hidden";
	var FOLD_H = 44;
	function ensurePageCss() {
		if (document.getElementById(PAGE_CSS_ID)) return;
		const s = document.createElement("style");
		s.id = PAGE_CSS_ID;
		s.textContent = page_default;
		document.head.appendChild(s);
	}
	function statsNodes(r) {
		const t = r?.hidden;
		const cell = (n, l) => h("div", { class: "stat" }, h("b", {}, String(n ?? "–")), h("span", {}, l));
		return [
			cell(t?.today, "today"),
			cell(t?.week, "week"),
			cell(t?.month, "month"),
			cell(t?.total, "all time"),
			h("div", {
				class: "dial",
				title: t ? `Today ${t.today} · record ${t.record}` : ""
			}, dialEl(t ?? {
				dial: 0,
				isNewRecord: false
			}, DIAL_PX))
		];
	}
	var MEASURE_ATTR = "data-slopmop-measure";
	var REVEAL_ATTR = "data-slopmop-reveal";
	/** How long the unfold animation runs; matches the height transition in fold.css. */
	var UNFOLD_MS = 640;
	var DIAL_PX = 44;
	var REDUCED_MOTION = "(prefers-reduced-motion: reduce)";
	/** The folded-paper strip: two halves, a crease, the brand line and the stats. */
	function buildStrip(statsEl) {
		return h("div", {
			class: "wrap",
			role: "button",
			tabindex: 0,
			"aria-label": "This post was hidden by Slop Mop. Activate to show it."
		}, h("div", { class: "half top" }), h("div", { class: "half bot" }), h("div", { class: "crease" }), h("div", { class: "content" }, h("div", { class: "brand" }, mopIcon(18, PALETTE.ink400), h("span", { class: "label" }, "This post was hidden")), statsEl, h("span", { class: "show" }, "Show post")));
	}
	/** The post's height at the strip's width, measured without disturbing the page's layout. */
	function heightAtWidth(post, width) {
		post.removeAttribute(HIDDEN_ATTR);
		post.setAttribute(MEASURE_ATTR, "");
		post.style.width = `${width}px`;
		const height = post.offsetHeight;
		post.removeAttribute(MEASURE_ATTR);
		post.style.width = "";
		post.setAttribute(HIDDEN_ATTR, "");
		return height;
	}
	/** Runs `action` on click or Enter/Space. */
	function onActivate(el, action) {
		el.addEventListener("click", action);
		el.addEventListener("keydown", (e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				action();
			}
		});
	}
	/** Inserts a folded-paper strip before `post` and hides the post. Click/Enter unfolds and restores it. */
	function fold(post, d, stats, onRestore, inspect) {
		ensurePageCss();
		const host = document.createElement("div");
		host.setAttribute("data-slopmop-fold", "");
		host.style.setProperty("--fold-h", `${FOLD_H}px`);
		const statsEl = h("div", { class: "stats" }, ...statsNodes(stats));
		const wrap = buildStrip(statsEl);
		host.attachShadow({ mode: "open" }).append(style(tokens_default + fold_default), wrap);
		post.parentElement?.insertBefore(host, post);
		post.setAttribute(HIDDEN_ATTR, "");
		if (inspect) bindInspector(wrap, inspect);
		const finish = () => {
			post.removeAttribute(HIDDEN_ATTR);
			post.setAttribute(REVEAL_ATTR, "");
			host.remove();
			onRestore();
		};
		let opened = false;
		onActivate(wrap, () => {
			if (opened) return;
			opened = true;
			closeInspector();
			const height = heightAtWidth(post, wrap.offsetWidth);
			if (matchMedia(REDUCED_MOTION).matches || height <= FOLD_H) return finish();
			wrap.classList.add("open");
			wrap.style.height = `${height}px`;
			setTimeout(finish, UNFOLD_MS);
		});
		return {
			host,
			updateStats: (r) => statsEl.replaceChildren(...statsNodes(r)),
			remove: () => {
				host.remove();
				post.removeAttribute(HIDDEN_ATTR);
			}
		};
	}
	//#endregion
	//#region src/content/highlight.ts
	var COLORS = {
		green: PALETTE.blue500,
		yellow: PALETTE.mop500,
		red: PALETTE.red500
	};
	/** A 3px coloured border round the post. Nothing else is added to the post: the score and details live in the mop menu. */
	function ring(post, color) {
		const prev = {
			shadow: post.style.boxShadow,
			radius: post.style.borderRadius
		};
		post.style.boxShadow = `0 0 0 3px ${color}`;
		post.style.borderRadius ||= "8px";
		return { remove() {
			post.style.boxShadow = prev.shadow;
			post.style.borderRadius = prev.radius;
		} };
	}
	/** Highlight mode: yellow/red border for other people's posts. */
	var outline = (post, d) => ring(post, d.level === "red" ? COLORS.red : COLORS.yellow);
	/** Your own posts: always blue (clean), yellow or red. */
	var ownOutline = (post, level) => ring(post, COLORS[level]);
	/** Your vote: blue = no, yellow = maybe, red = probably. */
	var voteOutline = (post, vote) => ring(post, COLORS[voteLevel(vote)]);
	/** A post you unfolded keeps its red border; "Hide post again" is in the mop menu. */
	var refoldRing = (post) => ring(post, COLORS.red);
	//#endregion
	//#region src/content/styles/voteButton.css?inline
	var voteButton_default = ":host{all:initial;display:inline-flex;align-items:center;vertical-align:middle;flex:none}\nbutton{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;cursor:pointer;transition:var(--transition-ui)}\nbutton:hover{background:var(--paper-200)}\nbutton:focus-visible{box-shadow:var(--shadow-focus)}\n";
	//#endregion
	//#region src/content/voteButton.ts
	var GREY = PALETTE.ink500;
	var glyph = (color) => mopIcon(20, color, PALETTE.paper000);
	/** Rectangles overlap or are on clearly different rows: the icon did not land beside the "..." button. */
	function misplaced(a, b) {
		if (!a.width || !b.width) return false;
		return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top || Math.abs(a.top + a.height / 2 - (b.top + b.height / 2)) > 20;
	}
	function createVoteButton(post, onOpen) {
		const host = document.createElement("div");
		host.setAttribute("data-slopmop-vote", "");
		const root = host.attachShadow({ mode: "open" });
		const button = h("button", {
			type: "button",
			"aria-haspopup": "menu",
			"aria-label": "Slop Mop: is this post slop?",
			title: "Is this post slop?"
		});
		button.append(glyph(GREY));
		button.addEventListener("click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			onOpen(button);
		});
		root.append(style(tokens_default + voteButton_default), button);
		const menuBtn = post.querySelector(SEL.authorAria);
		const floatInCorner = () => {
			host.style.cssText = "position:absolute;top:8px;right:104px;z-index:5";
			if (getComputedStyle(post).position === "static") post.style.position = "relative";
			post.appendChild(host);
		};
		if (menuBtn?.parentElement) {
			menuBtn.before(host);
			const cs = getComputedStyle(menuBtn);
			host.style.alignSelf = cs.alignSelf;
			host.style.marginTop = cs.marginTop;
			host.style.marginBottom = cs.marginBottom;
			requestAnimationFrame(() => {
				if (!host.isConnected) return;
				const h = host.getBoundingClientRect();
				const m = menuBtn.getBoundingClientRect();
				const dy = m.top - h.top;
				if (h.width && Math.abs(dy) > .5 && Math.abs(dy) <= 24) host.style.marginTop = `${(parseFloat(host.style.marginTop) || 0) + dy}px`;
				if (misplaced(host.getBoundingClientRect(), m)) floatInCorner();
			});
		} else floatInCorner();
		return {
			host,
			button,
			setVote(v) {
				const c = v ? VOTE_COLOR[v] : GREY;
				button.replaceChildren(glyph(c));
				const label = v ? `Slop Mop: you voted "${VOTE_NAME[v]}"` : "Slop Mop: is this post slop?";
				button.setAttribute("aria-label", label);
				button.title = v ? `Your vote: ${VOTE_NAME[v]}` : "Is this post slop?";
			},
			remove: () => host.remove()
		};
	}
	//#endregion
	//#region src/content/styles/voteMenu.css?inline
	var voteMenu_default = ":host{all:initial}\n*{box-sizing:border-box}\n.menu{position:fixed;z-index:2147483001;width:252px;background:var(--surface-card);color:var(--text-body);border:var(--border-width) solid var(--border-hairline);border-radius:var(--radius-md);padding:var(--space-3) 0;box-shadow:var(--shadow-pop);font:var(--type-body-sm)}\n.score{padding:var(--space-4) var(--space-6)}\n.score .row{display:flex;align-items:baseline;gap:var(--space-3)}\n.score .k{font:var(--type-label);color:var(--text-muted)}\n.score .v{font:var(--type-mono);font-weight:var(--weight-medium);color:var(--text-body);font-variant-numeric:tabular-nums}\n.score .verdict{font:var(--weight-semibold) var(--text-lg)/1.2 var(--font-display);letter-spacing:var(--tracking-tight)}\n.score .meter{position:relative;display:flex;height:6px;border-radius:var(--radius-pill);margin:var(--space-4) 0 var(--space-3)}\n.score .meter i{display:block;height:100%}\n.score .meter i:first-child{border-radius:var(--radius-pill) 0 0 var(--radius-pill)}\n.score .meter i:nth-of-type(3){border-radius:0 var(--radius-pill) var(--radius-pill) 0}\n.score .meter b{position:absolute;top:-3px;width:12px;height:12px;margin-left:-6px;border-radius:50%;background:var(--ink-900);border:2px solid var(--paper-000);box-shadow:var(--shadow-raised)}\n.score .err{margin-top:var(--space-2);font:var(--type-label);color:var(--red-700)}\n.dots{display:inline-flex;align-items:center;gap:var(--space-2);height:22px;align-self:center}\n.dots i{display:block;width:5px;height:5px;border-radius:50%;background:var(--ink-400);animation:bounce 1s ease-in-out infinite}\n.dots i:nth-child(2){animation-delay:.15s}\n.dots i:nth-child(3){animation-delay:.3s}\n@keyframes bounce{0%,60%,100%{transform:translateY(0);opacity:.45}30%{transform:translateY(-5px);opacity:1}}\n@media (prefers-reduced-motion:reduce){.dots i{animation:pulse 1.4s ease-in-out infinite}@keyframes pulse{0%,100%{opacity:.35}50%{opacity:1}}}\n.score .community{margin-top:var(--space-3);font:var(--type-label);color:var(--text-muted)}\n.score .community b{color:var(--text-body);font-weight:var(--weight-semibold)}\n.title{padding:var(--space-3) var(--space-6) var(--space-2);font:var(--type-label);color:var(--text-muted)}\nbutton{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:var(--space-5);width:100%;padding:var(--space-4) var(--space-6);cursor:pointer;font:var(--type-ui);transition:var(--transition-ui)}\nbutton:hover,button:focus-visible{background:var(--paper-100)}\nbutton:focus-visible{box-shadow:inset 0 0 0 2px var(--focus-ring)}\nbutton[disabled],button[aria-disabled=true]{opacity:.45;cursor:default}\n.dot{flex:none;width:12px;height:12px;border-radius:50%}\n.name{font-weight:var(--weight-semibold)}.hint{color:var(--text-muted);font:var(--type-label)}\n.check{margin-left:auto;font-weight:var(--weight-bold);color:var(--blue-700)}\nhr{border:0;border-top:1px solid var(--border-hairline);margin:var(--space-3) 0}\n.quiet{color:var(--text-muted)}\n.chev{margin-left:auto;color:var(--text-faint);font-size:16px;line-height:1}\n.err-msg{padding:var(--space-3) var(--space-6) var(--space-2);color:var(--red-700);font:var(--type-label)}\n";
	//#endregion
	//#region src/content/voteMenuBehavior.ts
	/** Where the menu goes, and how it closes: placement, keyboard and dismissal. */
	var MENU_GAP_PX = 4;
	var VIEWPORT_MARGIN_PX = 8;
	/** Right-aligned under the icon, like the native "..." menu; flips above if there is no room below. */
	function placeBelow(anchor, menu) {
		const a = anchor.getBoundingClientRect();
		const mw = menu.offsetWidth;
		const mh = menu.offsetHeight;
		const top = a.bottom + MENU_GAP_PX + mh > window.innerHeight - VIEWPORT_MARGIN_PX ? Math.max(VIEWPORT_MARGIN_PX, a.top - mh - MENU_GAP_PX) : a.bottom + MENU_GAP_PX;
		menu.style.top = `${top}px`;
		menu.style.left = `${Math.min(Math.max(VIEWPORT_MARGIN_PX, a.right - mw), window.innerWidth - mw - VIEWPORT_MARGIN_PX)}px`;
	}
	/** Arrow keys, Home/End move between items; Escape and Tab close. */
	function menuKeys(items, shadow, close) {
		return (e) => {
			if (e.key === "Escape") return void (e.preventDefault(), close(true));
			const i = items.indexOf(shadow.activeElement);
			const move = (n) => (e.preventDefault(), items[(n + items.length) % items.length].focus());
			if (e.key === "ArrowDown") move(i + 1);
			else if (e.key === "ArrowUp") move(i - 1);
			else if (e.key === "Home") move(0);
			else if (e.key === "End") move(items.length - 1);
			else if (e.key === "Tab") close(true);
		};
	}
	/** Closes the menu on an outside press, Escape/Tab, scrolling or resizing. Returns the function that stops listening. */
	function closeOnDismissal(menu, anchor, onKey, close) {
		const onDown = (e) => {
			const path = e.composedPath();
			if (!path.includes(menu) && !path.includes(anchor)) close(false);
		};
		const onScroll = () => close(false);
		document.addEventListener("pointerdown", onDown, true);
		document.addEventListener("keydown", onKey, true);
		window.addEventListener("scroll", onScroll, true);
		window.addEventListener("resize", onScroll);
		return () => {
			document.removeEventListener("pointerdown", onDown, true);
			document.removeEventListener("keydown", onKey, true);
			window.removeEventListener("scroll", onScroll, true);
			window.removeEventListener("resize", onScroll);
		};
	}
	//#endregion
	//#region src/content/voteMenuParts.ts
	var TONE = {
		green: PALETTE.blue500,
		yellow: PALETTE.mop900,
		red: PALETTE.red500,
		grey: PALETTE.ink600
	};
	/** "3 flagged as slop · 1 maybe · 2 no", or a note that nobody has voted yet. */
	function communityLine(c) {
		if (c.total === 0) return h("div", { class: "community" }, "No community votes yet");
		return h("div", { class: "community" }, "Community: ", h("b", {}, `${c.probably} flagged as slop`), ` · ${c.maybe} maybe · ${c.no} no`);
	}
	/** A thin bar of the three zones (looks fine, possibly, likely) with a marker at the shown score. */
	function meter(score, zones) {
		const { possibly: displayPossibly, likely: displayLikely } = zones;
		return h("div", {
			class: "meter",
			role: "img",
			"aria-label": `Slop score ${score} out of 100`
		}, h("i", { style: `width:${displayPossibly}%;background:${PALETTE.blue200}` }), h("i", { style: `width:${displayLikely - displayPossibly}%;background:${PALETTE.mop200}` }), h("i", { style: `flex:1;background:${PALETTE.red200}` }), h("b", { style: `left:${Math.min(100, Math.max(0, score))}%` }));
	}
	/** The score at the top of the menu: three bouncing dots while scoring, then the number, the verdict and the community line. */
	function scoreSection(getState) {
		const box = h("div", {
			class: "score",
			"aria-live": "polite"
		});
		const label = h("span", { class: "k" }, "Slop score");
		const paint = () => {
			const s = getState();
			box.replaceChildren();
			if (s.problem) return box.append(h("div", { class: "row" }, label), h("div", { class: "err" }, s.problem));
			if (s.score === null) {
				const dots = h("span", {
					class: "dots",
					role: "img",
					"aria-label": "Scoring"
				}, h("i", {}), h("i", {}), h("i", {}));
				return box.append(h("div", { class: "row" }, label, dots), h("div", {
					class: "verdict",
					style: "color:var(--text-faint)"
				}, "Scoring…"));
			}
			box.append(h("div", {
				class: "verdict",
				style: `color:${TONE[s.tone]}`
			}, s.verdict), meter(s.score, s.zones), h("div", { class: "row" }, label, h("span", { class: "v" }, String(s.score))), ...s.community ? [communityLine(s.community)] : []);
		};
		return {
			box,
			paint
		};
	}
	/** "Details": shows the analysis card on hover or focus (not click), so it never gets in the way of the post underneath. */
	function detailsItem(getState, menu) {
		const button = h("button", {
			type: "button",
			role: "menuitem",
			"aria-haspopup": "true",
			class: "quiet"
		}, h("span", { class: "name" }, "Details"), h("span", {
			class: "chev",
			"aria-hidden": "true"
		}, "‹"));
		const show = () => {
			const inspect = getState().inspect;
			if (inspect) showInspectorBeside(menu(), inspect);
		};
		for (const event of [
			"mouseenter",
			"focus",
			"click"
		]) button.addEventListener(event, show);
		for (const event of ["mouseleave", "blur"]) button.addEventListener(event, closeInspector);
		const paint = () => {
			const ready = !!getState().inspect;
			button.setAttribute("aria-disabled", String(!ready));
			button.title = ready ? "" : "Available once the post has been scored";
		};
		return {
			button,
			paint
		};
	}
	/** One of the three vote choices. Choosing your current vote again clears it. */
	function voteRadio(v, current, pick) {
		const b = h("button", {
			type: "button",
			role: "menuitemradio",
			"aria-checked": String(current === v),
			"data-v": v
		}, h("span", {
			class: "dot",
			style: `background:${VOTE_COLOR[v]}`
		}), h("span", { class: "name" }, VOTE_NAME[v]), h("span", { class: "hint" }, VOTE_HINT[v]), current === v ? h("span", {
			class: "check",
			"aria-hidden": "true"
		}, "✓") : null);
		b.addEventListener("click", () => pick(current === v ? null : v, b));
		return b;
	}
	/** A plain text item under the votes ("Clear my vote", "Hide post again"). */
	var quietItem = (label, onClick) => {
		const b = h("button", {
			type: "button",
			role: "menuitem",
			class: "quiet"
		}, label);
		b.addEventListener("click", () => onClick(b));
		return b;
	};
	//#endregion
	//#region src/content/voteMenu.ts
	var host = null;
	var root = null;
	var openState = null;
	function ensureHost() {
		if (host?.isConnected && root) return root;
		host = document.createElement("div");
		host.setAttribute("data-slopmop-menu", "");
		root = host.attachShadow({ mode: "open" });
		root.append(style(tokens_default + voteMenu_default));
		document.body.appendChild(host);
		return root;
	}
	function closeVoteMenu() {
		openState?.close();
	}
	function openVoteMenu(anchor, opts) {
		if (openState?.anchor === anchor) return closeVoteMenu();
		closeVoteMenu();
		closeInspector();
		const shadow = ensureHost();
		const initial = opts.getState();
		const errMsg = h("div", {
			class: "err-msg",
			role: "alert"
		});
		let menu;
		let stopListening = () => {};
		const close = (refocus) => {
			stopListening();
			closeInspector();
			menu.remove();
			openState = null;
			if (refocus) anchor.focus();
		};
		const pick = async (v, btn) => {
			items.forEach((b) => b.disabled = true);
			errMsg.textContent = "";
			const problem = await opts.onPick(v).catch(() => "Something went wrong saving that vote.");
			if (!problem) return close(true);
			errMsg.textContent = problem;
			items.forEach((b) => b.disabled = false);
			btn.focus();
		};
		const score = scoreSection(opts.getState);
		const details = detailsItem(opts.getState, () => menu);
		const radios = [
			"no",
			"maybe",
			"probably"
		].map((v) => voteRadio(v, initial.current, (vote, btn) => void pick(vote, btn)));
		const clearBtn = initial.current ? quietItem("Clear my vote", (self) => void pick(null, self)) : null;
		const refoldBtn = initial.canRefold ? quietItem("Hide post again", () => (close(false), opts.onRefold())) : null;
		const items = [
			...radios,
			...clearBtn ? [clearBtn] : [],
			...refoldBtn ? [refoldBtn] : [],
			details.button
		];
		menu = h("div", {
			class: "menu",
			role: "menu",
			"aria-label": "Slop Mop"
		}, score.box, h("hr"), h("div", { class: "title" }, "Is this post slop?"), ...radios, clearBtn, refoldBtn, errMsg, h("hr"), details.button);
		score.paint();
		details.paint();
		shadow.append(menu);
		placeBelow(anchor, menu);
		if (initial.score === null && !initial.problem) opts.ensure().finally(() => {
			if (openState?.anchor !== anchor) return;
			score.paint();
			details.paint();
			placeBelow(anchor, menu);
		});
		stopListening = closeOnDismissal(menu, anchor, menuKeys(items, shadow, close), close);
		openState = {
			anchor,
			close: () => close(false)
		};
		(radios.find((b) => b.getAttribute("data-v") === initial.current) ?? radios[0]).focus();
	}
	//#endregion
	//#region src/content/voting.ts
	/** Puts the mop icon beside a post's "…" menu (if it isn't there already), wired to its vote menu. */
	function ensureButton(t) {
		if (!active() || t.vbtn?.host.isConnected) return;
		t.vbtn = createVoteButton(t.el, (button) => openVoteMenu(button, {
			getState: () => menuState(t),
			ensure: async () => void await ensureVerdict(t),
			onPick: (v) => castVote(t, v),
			onRefold: () => hideAgain(t)
		}));
		t.vbtn.setVote(voteOf(t.urn));
	}
	/** Folds a post the user had unfolded back up. */
	function hideAgain(t) {
		t.refold?.remove();
		t.refold = void 0;
		t.restored = false;
		restored.delete(t.urn);
		hooks.render(t);
	}
	/** Keeps the community line current right after you vote, without waiting for the server (which gets your vote in the background). */
	function adjustCommunity(t, before, after) {
		if (!t.community) return;
		const c = { ...t.community };
		if (before) c[before] = Math.max(0, c[before] - 1);
		if (after) c[after] += 1;
		c.total = c.no + c.maybe + c.probably;
		t.community = c;
	}
	/** Applies a vote (or clears it). Returns a message to show in the menu when it can't be recorded. */
	async function castVote(t, vote) {
		const before = voteOf(t.urn);
		if (vote === null) {
			await send({
				type: "unvote",
				urn: t.urn
			});
			dropVote(t.urn);
			adjustCommunity(t, before, null);
		} else {
			const response = await ensureVerdict(t);
			if (!response) return `Couldn't score this post, so the vote wasn't saved. ${t.failure ?? ""}`.trim();
			const d = decisionFor(t);
			const { settings } = state;
			const record = {
				urn: t.urn,
				network: response.network ?? "linkedin",
				contentId: response.contentId,
				label: vote,
				at: Date.now(),
				text: t.text,
				own: t.own,
				engagement: t.engagement,
				verdict: response,
				decided: {
					level: d.level,
					score: d.score,
					mode: settings.mode,
					sensitivity: settings.sensitivity
				}
			};
			await send({
				type: "vote",
				record
			});
			setVote(record);
			adjustCommunity(t, before, vote);
			if (voteHides(vote)) hideAgain(t);
		}
		hooks.render(t);
		return null;
	}
	//#endregion
	//#region src/content/render.ts
	/** Removes one drawn thing from a post, if it is there. */
	function drop(t, slot) {
		t[slot]?.remove();
		t[slot] = void 0;
		if (slot === "outline") t.outlineKey = void 0;
	}
	/** Removes everything the extension drew on a post. */
	function clear(t) {
		for (const slot of [
			"fold",
			"outline",
			"refold"
		]) drop(t, slot);
		t.vbtn?.remove();
		t.vbtn = void 0;
	}
	/** Counts a hidden or flagged post once, and refreshes the stats shown on every fold strip. */
	async function count(t, kind) {
		if (t.counted === kind) return;
		t.counted = kind;
		state.lastStats = await send({
			type: "record",
			kind,
			urn: t.urn
		});
		for (const p of posts.values()) p.fold?.updateStats(state.lastStats);
	}
	/** Runs UI work that must never break the page: a failure is logged and the post stays visible and untouched. */
	function failOpen(what, t, fn) {
		try {
			fn();
		} catch (e) {
			console.warn(`[slopmop] ${what} failed; leaving post visible`, e);
			t.el.removeAttribute("data-slopmop-hidden");
		}
	}
	/** Folds the post away. Unfolding keeps a red ring on it; "Hide post again" is in the mop menu. */
	function showFold(t, d, inspect) {
		failOpen("fold", t, () => {
			drop(t, "refold");
			t.fold = fold(t.el, d, state.lastStats, () => {
				t.restored = true;
				restored.add(t.urn);
				t.fold = void 0;
				t.refold = refoldRing(t.el);
			}, inspect);
			count(t, "hidden");
		});
	}
	/** Draws what `want` says, changing only what differs from what is there now. */
	function reconcile(t, want, d, inspect) {
		if (!want.fold) drop(t, "fold");
		if (!want.refold) drop(t, "refold");
		if (!want.outline || t.outlineKey !== want.outline.key) drop(t, "outline");
		if (want.fold && !t.fold) showFold(t, d, inspect);
		if (want.refold && !t.refold && !t.fold) t.refold = refoldRing(t.el);
		if (want.outline && !t.outline) showOutline(t, want.outline);
	}
	/** Draws the border. A border from the score counts as a flagged post (once). */
	function showOutline(t, want) {
		try {
			t.outline = want.kind === "vote" ? voteOutline(t.el, want.vote) : want.kind === "own" ? ownOutline(t.el, want.level) : outline(t.el, want.decision);
			t.outlineKey = want.key;
			if (want.kind === "score") count(t, "flagged");
		} catch (e) {
			console.warn(`[slopmop] ${want.kind} outline failed`, e);
		}
	}
	/** Re-decides from cached raw answers; used after every settings change too (no re-inference). */
	function render(t) {
		if (!t.el.isConnected) return;
		if (!active() || !t.own && isAd(t.el)) return clear(t);
		ensureButton(t);
		const vote = voteOf(t.urn);
		t.vbtn?.setVote(vote);
		if (t.done && !t.response && !vote && !t.own) return;
		const { settings } = state;
		const own = t.own ? decideOwn(t.response, settings.sensitivity, scoringParams()) : null;
		const decision = own ?? decide(t.response, t.engagement, settings.mode, settings.sensitivity, { params: scoringParams() });
		const want = desiredView({
			decision,
			mode: settings.mode,
			vote,
			restored: t.restored,
			own: t.own,
			inspectOnly: t.inspectOnly,
			scored: !!t.response,
			ownLevel: own?.ownLevel
		});
		if (!want) {
			if (t.outlineKey?.startsWith("vote:")) drop(t, "outline");
			return;
		}
		reconcile(t, want, decision, inspectFor(t));
	}
	//#endregion
	//#region src/content/track.ts
	/** Counts something seen once, and tells the popup's debug panel. */
	function tally(urn, key) {
		const id = `${key}:${urn ?? Math.random()}`;
		if (counted.has(id)) return;
		counted.add(id);
		seen[key]++;
		send({
			type: "debug",
			...seen
		});
	}
	/** Remembers the signed-in user's name (from the page), so their own posts are recognised. */
	function learnOwnName() {
		state.ownName ??= findOwnName();
		if (state.ownName && !state.learnedName) {
			state.learnedName = true;
			chrome.storage.local.set({ ownName: state.ownName });
		}
	}
	/** Reads the post's counts again; when they have grown a step, the server is asked for a fresh shield. */
	function refreshEngagement(t) {
		const now = readEngagement(t.el);
		if (engagementBand(now) <= engagementBand(t.engagement)) return;
		t.engagement = now;
		recheck(t);
	}
	function track(el) {
		const known = byEl.get(el);
		if (known) {
			if (getUrn(el) === known.urn) {
				refreshEngagement(known);
				return ensureButton(known);
			}
			clear(known);
			byEl.delete(el);
		}
		learnOwnName();
		const r = inspectPost(el, state.ownName, true);
		if (r.status === "ad") return tally(getUrn(el), "ads");
		if (r.status !== "ok") return tally(getUrn(el), "skipped");
		const x = r.post;
		tally(x.urn, "detected");
		if (x.own) tally(x.urn, "own");
		const t = {
			el,
			urn: x.urn,
			engagement: x.engagement,
			text: x.text,
			own: x.own,
			inspectOnly: !!x.inspectOnly,
			done: false,
			failure: null,
			retries: 0,
			requested: false,
			response: null,
			restored: restored.has(x.urn)
		};
		byEl.set(el, t);
		posts.set(x.urn, t);
		observerFor(el).observe(el);
		ensureButton(t);
	}
	//#endregion
	//#region src/content/feed.ts
	/** Finds every post under `root` and starts tracking the new ones. */
	function scan(root = document) {
		if (!extensionAlive()) return hooks.shutdown();
		syncComposer();
		if (!active()) return;
		root.querySelectorAll(POST_SELECTOR).forEach(track);
		if (root instanceof HTMLElement && root.matches(POST_SELECTOR)) track(root);
	}
	/** Redraws every post (after a settings change). */
	function renderAll() {
		for (const t of posts.values()) {
			if (!active()) {
				clear(t);
				continue;
			}
			if (!t.requested) {
				const io = observerFor(t.el);
				io.unobserve(t.el);
				io.observe(t.el);
			}
			render(t);
		}
	}
	/** Rescans (shortly after the page changes) so posts that load as the feed grows are picked up. */
	var feedWatcher = null;
	function stopFeed() {
		feedWatcher?.disconnect();
		feedWatcher = null;
	}
	function watchFeed() {
		let queued = 0;
		feedWatcher = new MutationObserver(() => {
			if (queued) return;
			queued = window.setTimeout(() => {
				queued = 0;
				scan();
			}, live.values.rescanDelayMs);
		});
		feedWatcher.observe(document.body, {
			childList: true,
			subtree: true
		});
	}
	/** Follows settings changes made in the popup, with no reload. */
	function watchSettings() {
		chrome.storage.onChanged.addListener((changes, area) => {
			if (area === "local" && changes["manifest"]) return renderAll();
			if (area !== "sync" || !changes.settings) return;
			const was = active();
			state.settings = {
				...DEFAULT_SETTINGS,
				...changes.settings.newValue
			};
			if (!active()) closeVoteMenu(), closeInspector();
			if (!was && active()) scan();
			renderAll();
		});
	}
	//#endregion
	//#region src/content/index.ts
	/** The content script's entry point: it runs on LinkedIn pages, finds posts, and wires everything up. */
	async function init() {
		state.settings = await getSettings();
		await watchManifest();
		state.ownName = (await chrome.storage.local.get("ownName")).ownName ?? null;
		state.learnedName = !!state.ownName;
		await loadVotes();
		watchVotes((urn) => {
			const t = posts.get(urn);
			if (t) render(t);
		});
		scan();
		watchFeed();
		watchSettings();
		send({ type: "pageStart" }).catch(() => void 0);
		send({ type: "getStats" }).then((stats) => state.lastStats = stats ?? null).catch(() => void 0);
	}
	/** The extension was reloaded or removed while this page kept running: stop, and leave the page as LinkedIn made it. */
	function shutdown() {
		stopFeed();
		stopObserving();
		for (const t of posts.values()) clear(t);
		closeVoteMenu();
		closeInspector();
		clearComposer();
	}
	hooks.render = render;
	hooks.shutdown = shutdown;
	whenExtensionGone(shutdown);
	watchScrolling();
	init();
	//#endregion
})();
